# M2D

**A width-parameterized digit-serial RV32I core and pure-Python synthesis flow for quantifying the optimal RISC-V design point on MoS2 2D semiconductors**

This repository is a design-space study that quantifies **at which physical
conditions of a 2D semiconductor the optimal RISC-V datapath width transitions
from bit-serial to parallel** (IEEE Access manuscript: *Datapath Width Design Space of 32-Bit RISC-V
Processors for 2D Semiconductor Logic*). The body of the study and
its conclusions are in that manuscript; all data behind it are in `results/`
(regenerable with `python3 study.py`).

Verification stack: **formal (SAT) equivalence of every mapping, buffering and
sub-cycle pipelining step at all 9 design points of both configurations**
(`m2d/pdk2d/formal.py`, `tools/prove_flow.py`, `tools/prove_rf_system.py`,
`results/formal.md`) → exact
per-instruction-class cycle verification 117/117 → **gate-level execution of the
workloads on the mapped netlists of all 9 design points** (asserting that cycle
counts match RTL exactly and that checksums match the golden ISS; the measured
α is also obtained here) → **depth-compliant physical netlists of all 9 design
points** (real DFFHQ sub-cycle pipelining to ≤ 17 stages, DRC PASS, formally
proved equivalent to the mapped netlists over one architectural cycle and executing the workload at
gate level at sub-cycle granularity) → yosys+ABC independent-mapper cross-check with **both mappers fan-out legalized**
(measured QoR factors: T ≈ 1.5×, depth ripple 1.48–1.69× / prefix 1.12×). The
yield axis is placed against the yield data of Ao *et al.*: 99.92% per
transistor (800 defects per 10⁶ T), 898/900 inverters, and the 144-T and
1,152-T register blocks of Supplementary Fig. 7 (`tools/block_yield.py`,
`results/block_yield.md`), which give a block-level density of 2,394 ppm/T and
a negative-binomial clustering parameter α = 30 (95% lower bound 1.3).
**2025 MoS₂ lies inside the bit-serial region (it reproduces the design choice
of the actual chip)** under Poisson statistics and at the fitted (d, α); the
selection changes only for α below the break-even values of
`results/nb_sensitivity.md` (5.0 / 3.7 / 3.1 delay-budget, 2.1 / 0.9 cascade),
which the register data do not yet exclude except 0.9.

The core starts from an existing BSD-licensed RV32IM soft processor and was
fully redesigned as a **digit-serial** RV32I to match the constraints of
Ao *et al.*, "A RISC-V 32-bit microprocessor based on two-dimensional
semiconductors" (**RV32-WUJI**, *Nature* **640**, 654 (2025)): it processes W
bits per cycle (W ∈ {1, 2, 4, 8, 16, 32}), where W = 1 is the bit-serial design
point of the paper and W = 32 corresponds to a fully parallel datapath. The
digit adder can be selected between ripple carry (O(W) stages) and Brent–Kung
parallel prefix (O(log W) stages, maximum fanout 2 in the prefix network), so
that "serial vs. parallel" becomes a controlled variable of one fixed
microarchitecture. The study itself is in the manuscript; `results/` holds
every number it reports.

---

## 1. Layout

```
study.py                   Design-point sweep + measured CPI + scenario projection
results/study.{md,csv}     Sweep results (output of study.py)
results/phase.md           Phase diagram of the optimal W (PD-1/2/3) + λ_eff table
results/{workloads,validation,adders,boundaries}.md  Accompanying analyses
results/compiled_workloads.md  Compiled (Embench-IoT) dynamic mixes through the CPI model
results/compiled_spot.md   Compiled binaries executed at RTL, every design point
results/mix_envelope.md    Exact CPI-ratio bounds over EVERY instruction mix
results/coverage.md        Design-point x validation-stage coverage (generated)
results/depth_compliant.{md,json}  Depth-compliant (<= 17 stages) physical netlists of all 9 points
results/qor_sensitivity.md Mapper-quality sensitivity of the defect-density ladder
results/nb_sensitivity.md  Defect-clustering (negative-binomial) sensitivity of the retrodiction
results/embench_mixes.json Cached measured mixes (regenerate tables without a toolchain)
m2d/core.py                M2D(width, adder): digit-serial RV32I core
m2d/units/adders.py        Structural ripple / Brent-Kung prefix adders
m2d/units/regfile.py       SerialRegisterFile(width): external register file
m2d/sim.py                 M2DSim: simulation wrapper for core + RF
m2d/pdk2d/cells.py         25-cell 2D_NMOS_lib, noise margins, delay/power models
m2d/pdk2d/synth.py         Amaranth -> RTLIL -> yowasp-yosys -> Python techmap
m2d/pdk2d/techmap.py       Pure-Python technology mapper (constant propagation / AOI-OAI
                           covering / tree balancing / fanout legalization / equivalence check)
m2d/pdk2d/pipeline.py      Sub-cycle pipelining into <= 17-stage physical netlists + S-period
                           sequential equivalence check
m2d/pdk2d/analyze.py       Analysis and DRC of depth, fanout, delay and power
m2d/pdk2d/report.py        Comparison report against the published values
m2d/pdk2d/liberty.py       .lib output for external tools
m2d/elf.py                 Minimal ELF32-LE loader for compiled RV32I images
tools/build_embench.sh     Cross-compile Embench-IoT for the implemented RV32I subset
tools/audit_depth.py       Regression guard: no pre-v6.1 depth value anywhere in the tree
tools/depth_compliant.py   Resumable per-point driver of the depth-compliant flow
tools/{crt0.S,rv32i-flat.ld,boardsupport.c}  Bare-metal runtime for those binaries
tests/rv32.py              Mini assembler + golden RV32I ISS
tests/test_core2d.py       Co-simulation tests (122: every width x every adder)
tests/test_pipeline.py     Sub-cycle pipelining tests (DRC, equivalence, S-1 must fail, workload)
cli.py                     generate / synth / selftest / study / embench / coverage
```

## 2. Usage

```sh
pip install "amaranth[builtin-yosys]>=0.5,<0.6" yowasp-yosys numpy

python3 cli.py selftest                          # all 128 tests
python3 cli.py generate -t v out.v               # Verilog output (-t il for RTLIL)
python3 cli.py synth -o build                    # 2D synthesis + report for W=1
python3 cli.py --width 32 --adder prefix synth   # arbitrary design point
python3 cli.py synth --pipeline                  # + depth-compliant (<= 17 stages) physical netlist
python3 tools/depth_compliant.py                 # the same for all 9 points, resumable (results/depth_compliant.md)
python3 study.py                                 # full design-point sweep (tables of the paper)
python3 cli.py coverage                          # regenerate the coverage matrix
python3 cli.py embench                           # compiled workloads, from the cached mixes
```

Compiled workloads need an external bare-metal RISC-V toolchain and the
Embench-IoT sources; the measured mixes are cached, so the tables regenerate
without either. To reproduce them from source:

```sh
RISCV_GCC=/path/to/riscv-none-elf-gcc tools/build_embench.sh embench
python3 cli.py embench --refresh --spot slre ud sglib qrduino
```

`synth` produces `build/m2d_report.txt` (cell usage, DRC, timing, power,
comparison against the published values) and `build/m2d_mapped.json` (mapped
netlist). The exit code reflects the fanout DRC and the noise-margin DRC
(the logic depth of the mapped netlist exceeds the limit of the paper, which is
explicitly marked FAIL in the report; see §6). With `--pipeline` the mapped
netlist is additionally converted into the depth-compliant physical netlist
(`build/m2d_pipelined.json`, report in `build/m2d_pipelined_report.txt`, in
which the depth DRC is PASS and also enters the exit code).

## 3. Architecture

A W-bit/cycle digit-serial datapath whose `core.py` contains sections
corresponding to the 9-module organization of Fig. 5 of the paper (State /
Ctrl / Decode / ImmDecode / Bufreg / ALU / MEM_IF / Regfile_IF / CSR).

* **FSM** (common to all W): `FETCH → DECODE → [EXEC1] → [MEM] → EXEC2 → FETCH`.
Branches, JALR, SLT and shifts take two stages (`EXEC1`+`EXEC2`); loads/stores
go `EXEC1` (address addition) → `MEM` (bus transfer) → `EXEC2` (load write-back).
Each execution stage takes `32/W` cycles.
* **The PC is a rotating shift register**: during serial access it rotates by W
bits every cycle, the current digit is always `pc[0:W]`, and the updated digit
is re-inserted at the top. Since it realigns after `32/W` rotations, FETCH can
read it out in parallel. This is the same technique as RV32-WUJI/SERV, which
removes the 32:1 read MUX and the 32-way write demultiplexer entirely, and at
W = 32 it degenerates into an ordinary parallel register write (zero cost in
the parallel limit).
* **Digit ALU**: three W-bit adders (for the EXEC1 address / the EXEC2 ALU /
the PC; ripple or Brent–Kung selectable with `--adder`), an LSB-digit-first
serial comparator (eq is a W-bit XNOR reduction; ltu reuses the selected adder
as a subtractor: `~carry_out(a + ~b + 1)`, so choosing parallel addition also
makes comparison parallel), and AND/OR/XOR.
* **Shifts**: rs1 is captured into Bufreg in `EXEC1`. W = 1 uses the same
minimum-transistor scheme as the paper (a right shift pre-shifts during the
`shift_delay` countdown; a left shift reuses the same countdown as a zero test
for zero-filling the lower bits). For W > 1 a combinational barrel shifter
performs the shift in one go at the `EXEC1 → EXEC2` transition, and EXEC2
merely streams the digits. The shamt of a register operand (rs2[4:0]) is
recovered by reusing the store-data capture register (memdat), so no dedicated
shamt register exists for any W.
* **The register file is external** (as in the paper). Its interface is
2 reads / 1 write of W bits per cycle (`rf_*`; an ordinary 2R1W at W = 32).
This is because the 1,024 state bits of the RF alone exceed the 2D transistor
budget (Suppl. Fig. 7).
* **Reset minimization**: only the PC and the FSM state have resets. Every
other register is necessarily initialized at DECODE/transitions and is
therefore `reset_less`, which removes about 115 reset MUXes.
* The supported instructions are the same 37 RV32I instructions as the paper.
CSRs, exceptions and FENCE are not implemented (as in the paper, FENCE is
treated as a NOP). Addresses are assumed to be naturally aligned.

## 4. PDK provenance & calibration

All numbers in `pdk2d/cells.py` are taken from the paper:

* Types and uses of the 25 cells: Extended Data Fig. 4 (2D_NMOS_lib).
* Noise margins: Fig. 3b. Cells with **NM < 5% Vdd (0.2 V)**
(NOR4, NAND4, AOI33, AOI222, OAI33, OAI221, OAI222) are excluded from the PDK
and are not used by the mapper.
* Transistor count: estimated from the series-parallel configuration of E/D-NMOS
(driver branch, 2T per inverting input + 1T depletion load), with DFFHQ
calibrated to an 8-bit register = 144T (18T/FF, Suppl. Fig. 7).
* Delay: linear model `t = 4.06 µs + 0.6 µs/pF × C_load`, input capacitance
2.5 pF/pin. At maximum fanout 4 (10 pF) one stage is 10.06 µs, and 17 stages =
**171 µs**, which matches the measurements of Fig. 3c/d.
* Power: statically dominated. 0.431 mW / 5,931 T = **72.67 nW/T**
(Extended Data Table 2).
* Design rules: fanout ≤ 4, logic depth between FFs ≤ 17, Vdd = 4 V, external
clock 1 kHz.

## 5. Synthesis flow

Since ABC is not available under yowasp-yosys (WASM), yosys is used down to the
gate level while technology mapping and optimization are done in pure Python:

1. Amaranth → RTLIL → yosys
(`proc; flatten; opt -full; techmap; simplemap; dfflegalize -cell $_DFF_P_`;
because DFFHQ has no reset, synchronous reset is expanded into datapath MUXes).
2. `techmap.py` reads the JSON netlist and, after direct mapping, iterates to a
fixpoint:

   * **Constant propagation / duplicate-input reduction**: computes the residual
truth table with the constant inputs substituted and re-matches it to the
cheapest library cell, wire or power rail.
   * **Peephole covering**: INV pair cancellation, NAND3/NOR3/AND3 merging,
AOI21/22/31/32/211/221/2BB2 and OAI21/22/31/2BB2 covering,
input/output bubble absorption (NAND2B/NOR2B/NAND3B, De Morgan).
   * **Associative tree balancing**: rebuilds the left-associative AND/OR chains
left behind by yosys without ABC into balanced binary trees (only when the
depth genuinely decreases).
3. **Fanout legalization**: INV trees with an even number of stages and
alternating polarity (64 sinks in 2 stages, 1,024 sinks in 4 stages), which
halves the depth compared with chains of INV pairs. The constant nets c0/c1 are
excluded as power rails.
4. **Equivalence verification**: NumPy bit-parallel random simulation twice,
after mapping and after buffer insertion (8,192 patterns, treating the Q of the
FFs as pseudo-PIs and comparing all POs plus all FF Ds).
5. Analysis, DRC and report generation.
6. **Sub-cycle pipelining** (`pipeline.py`, optional; `synth --pipeline`,
`study.py`, `tools/depth_compliant.py`): the mapped netlist is converted into a
*physical* netlist that satisfies the ≤ 17-stage rule of the paper while
keeping the architecture and its cycle counts. One architectural cycle becomes
S physical clock periods, generated by a one-hot ring counter of S DFFHQ;
every architectural flip-flop gets a hold MUX2 (D' = en ? D : Q) unless its
next-state logic and everything reachable from its Q settle in the last
period ("hold-less" flip-flops); real DFFHQ pipeline registers are inserted on
every logic-driven net that crosses a cut (register chains when several cuts
are crossed; flip-flop outputs and input pads are full-swing and need none);
the S−1 cut levels are chosen by a dynamic programme that minimizes the
number of registers under the ≤ 17-level band constraint. Environment inputs
(memory and register-file responses) are scheduled by the level of the outputs
they depend on, i.e. with the same zero-wait, combinational environment as
the RTL benches, now at sub-cycle granularity. The result is analyzed by the
same DRC/timing flow as the mapped netlist (depth ≤ 17 and fan-out ≤ 4 must
PASS), formally proved equivalent to the mapped netlist over one
architectural cycle of S periods for all architectural states, pipeline
contents and environment garbage (`m2d/pdk2d/formal.py`; also checked by
bit-parallel random simulation; the same netlist with a ring of S−1 phases is
refuted), and executed at gate level at sub-cycle
granularity on a complete workload from a random initial state through reset,
asserting cycle count = RTL and result = golden ISS.

## 6. Results (`python3 study.py`; full discussion in the manuscript)

Excerpt of the main design points (all 9 are in `results/study.md`):

|W|Adder|T (NMOS)|Logic depth (before buffering)|Delay µs|CPI (geo. mean of 5 WLs)|instr/s @f_max|E/instr µJ @1 kHz|
|-:|-|-:|-:|-:|-:|-:|-:|
|1|ripple|10,474|34 (29)|241.1|50.0|82.9|38.05|
|8|prefix|17,979|44 (35)|334.2|8.16|366.5|10.67|
|16|prefix|21,327|50 (39)|385.6|5.19|499.9|8.04|
|32|ripple|25,679|125 (114)|874.6|3.70|309.2|6.90|
|32|prefix|27,195|56 (41)|426.4|3.70|634.2|7.31|

CPI is the geometric mean over 5 workloads (checksum / memcpy / softmul / sort /
popcount; the measured dynamic mix is in `results/workloads.md`). The
serial/parallel ratio is 11.8–15.1×, i.e. robust with respect to workload;
18 compiled Embench-IoT benchmarks give 11.71–15.31× (`results/compiled_workloads.md`)
and the exact bound over *every* possible instruction mix is 8.75–24.25×
(`results/mix_envelope.md`).

**Conclusions** (details and limitations in the manuscript, §VII and §VIII):

* Bit-serial (W = 1) is optimal **only in transistor count (= yield)**.
Fully parallel (W = 32, prefix) delivers **7.7× the throughput** for 2.6× the
transistors, and at a fixed 1 kHz **improves energy per instruction by
5.2–5.5×** (under static-power dominance E/instr ∝ T×CPI, so the 13.5×
difference in CPI overwhelms the 2.6× in T).
* **Multi-bit addition should use a parallel carry**: at 32 bits, ripple 96
stages → Brent–Kung 20 stages. Under the linear wire-capacitance model the
critical wire path length of BK is identical to that of ripple (both W pitches),
so **no crossover exists in principle**; even with distributed RC the crossing
point is 2.6 pF/pitch (beyond all measured pin loads). For the whole core,
+5.9 % transistors gives 2.05× f_max (1,143 → 2,345 Hz).
* **Phase diagram of the optimal W** (`results/phase.md`, §VI of the paper):
at the 1 kHz operating point, the transitions W = 32 → 16 → 8 → 4 → 2 → 1 reach
bit-serial only after a 3.5–4.1× degradation of the device delay (or a 3.7–9×
increase of the wire load). On the yield axis, d* = 38 / 90 / 195 defects/10⁶ T
(at f_max operation; 67 / 156 / 249 defects/10⁶ T at a fixed 1 kHz — these are
defect densities, not logic depths). M3D stacking expands each
boundary toward the parallel side by exactly √k (λ_eff is a derived quantity
depending on W and tier: flat 1.00–1.11 / 2-tier 0.72–0.79 / 4-tier 0.52–0.57).
In the leakage × wiring plane (CFET transition) **no bit-serial region exists**.

For reference: compared with the actual chip of the paper (W = 1), differences
of ×1.8 in transistors and ×2.0 in depth remain (10,474 T and 34 stages here
against 5,931 T and 17 stages). The main causes are the
absence of ABC-equivalent global restructuring and the manual optimizations of
the paper's chip (SERV-style serial immediate decoder, RF port sharing). None
of the mapped design points achieves depth ≤ 17 (marked FAIL in the report),
but the timing at the 1 kHz operating point is met at every point, and the
comparison holds as a relative evaluation within one identical flow.

**Depth-compliant physical netlists** (`results/depth_compliant.md`, §IV-G of
the manuscript). If the 17-stage rule of the fabricated chip is a hard
cascade constraint (E/D-NMOS level restoration) rather than a delay budget,
the mapped netlists above are not fabricable as they stand. Every design point
is therefore also implemented as a ≤ 17-stage physical netlist by the
sub-cycle pipelining of §5 step 6 (real DFFHQ insertion, not an analytic
estimate), clocked at the compliant 17-stage period of 171.02 µs (5,847 Hz)
with one architectural cycle = S periods, so that CPI_c = CPI × S:

|W|Adder|Depth|S|Cut regs|Hold MUX|T_c (NMOS)|T_c / T|Depth after|CPI_c|instr/s @f_c|E/instr µJ @f_c|
|-:|-|-:|-:|-:|-:|-:|-:|-:|-:|-:|-:|
|1|ripple|34|2|198|134|15,500|1.48|17 PASS|100.0|58.5|19.26|
|8|prefix|44|3|822|137|34,341|1.91|17 PASS|24.5|238.9|10.45|
|16|prefix|50|3|1,050|136|41,830|1.96|17 PASS|15.6|375.5|8.09|
|32|ripple|125|8|3,953|135|98,448|3.83|17 PASS|29.6|197.5|36.22|
|32|prefix|56|4|1,514|135|55,960|2.06|17 PASS|14.8|395.1|10.29|

All 9 physical netlists pass every design rule of the paper (depth ≤ 17,
fan-out ≤ 4, noise margin), are sequentially equivalent to the mapped netlists
(4,096 random cases each; the S−1 variants fail) and execute the checksum
workload at gate level with exactly the RTL cycle count and the ISS result.
Under strict compliance the transistor minimum stays at W = 1 (15,500 T), the
throughput optimum is W = 32 prefix (395 instr/s) and the energy optimum is
W = 16 prefix (8.09 µJ/instr) — the same optima as the main study at f_max, so
the serial-vs-parallel ordering is unchanged; W = 32 prefix delivers 6.8× the
throughput of W = 1 for 3.6× the transistors and 1.9× less energy per
instruction. The v6.3 analytic estimate (S = ⌈depth/17⌉, one register per net
and crossed cut, no hold logic) is kept as a comparison column in Table A of
`results/depth_compliant.md`. It gave the same S at every point but
overestimated T_c by 1.3 % (W = 1) to 13.0 % (W = 32 ripple): it counted
registers on flip-flop outputs and input pads, which need none, and omitted
the hold multiplexers. It is superseded by the implemented netlists.

## Installation

**Python 3.11 or later is required** (the dependencies are strictly pinned and
`numpy==2.4.4` requires 3.11+). Running inside a virtual environment is
recommended:

```sh
python3 --version                 # confirm 3.11+
python3 -m venv .venv
source .venv/bin/activate         # Windows: .venv\Scripts\activate
pip install -e .                  # to also generate the figures: pip install -e .[figs]

python3 cli.py selftest           # 128 tests (about 40 s)
python3 study.py                  # full sweep (about 10 min, single-threaded)
```

* If `error: externally-managed-environment` appears (PEP 668, the system Python
of Ubuntu 23.04+/Debian 12+), either use a venv as above or use
`pip install -e . --break-system-packages`.
* `ModuleNotFoundError: No module named 'amaranth'` is the symptom of missing
dependencies. Launch `cli.py` / `study.py` with the Python of the venv in which
`pip install -e .` was run at the top of the repository.
* Artifacts requiring no network: `results/` ships with all reports already
executed (`study.md`, `phase.md`, `io_model.md` and others) together with the
vector figures in `results/figs/`. The contents can be inspected without
re-running anything.

## 7. Verification

* **Formal equivalence** (`m2d/pdk2d/formal.py`, `results/formal.md`,
`results/rf_formal.json`): primitive ≡ mapped, mapped ≡ fan-out-legalized, and
legalized ≡ depth-compliant physical netlist over S periods, at all 9 design
points for the core alone and for the core with the register file. Both
netlists are built into one AIG with structural hashing; outputs whose literals
still differ are proved by CaDiCaL (python-sat). Negative controls: the S−1
ring is refuted at every point and 20/20 random single-cell mutants are refuted
at every point. `python3 tools/prove_flow.py` (seconds per point once
`build/` exists), `python3 tools/prove_rf_system.py 1:ripple ...`;
`tests/test_formal.py` repeats the W = 1 proofs.

* The arithmetic demonstration of Extended Data Fig. 7 of the paper
(1946 + 25 = 1971, +53 = 2024).
* Per-instruction tests: LUI/AUIPC, all branches (taken/not-taken/backward),
JAL/JALR, loads/stores of all widths (including negative offsets), boundary
values of the SLT family (SLTIU −1, 0x80000000), shifts of 0/1/31 and the
rs2[4:0] mask, x0 semantics.
* Random 120-instruction co-simulation against the golden RV32I ISS.
* The above suite re-run for all widths W ∈ {1, 2, 4, 8, 16, 32} × **both**
adders (122 tests in total; v6.1 covered prefix only at W ∈ {8, 32}, which left
W = 16 prefix uncovered). The Brent–Kung adder is separately
compared exhaustively against a Python reference implementation with 2,004
vectors per width for W = 2…32. The benchmark checksums are asserted to match
across all design points during the sweep.
* **Gate-level workload execution** (`study.py gate_level_sim`): the mapped
netlist is executed with two-phase cycle accuracy, asserting cycle count = RTL
and result = golden ISS (9/9 points). As a by-product, the switching activity
rate α and the pad bit toggles are measured.
* **Depth-compliant physical netlists** (`m2d/pdk2d/pipeline.py`,
`results/depth_compliant.md`): for all 9 design points the ≤ 17-stage
sub-cycle-pipelined netlist passes the DRC/timing analyzer (depth 17, 0
fan-out violations), is sequentially equivalent to the mapped netlist over S
periods (4,096 random cases from random architectural and pipeline states
with a garbage-before-arrival environment; the S−1 variant is asserted to
fail), and executes the checksum workload at gate level at sub-cycle
granularity from a random initial state through reset with the RTL cycle
count and the ISS result (9/9 points). `tests/test_pipeline.py` repeats this
for W = 1 ripple and W = 8 prefix with the memcpy workload and checks the cut
placement against brute force.
* **yosys+ABC cross-check** (`results/abc_crosscheck.md`): the same RTLIL is
mapped independently by ABC and analyzed with the same delay model. All
rankings are preserved.
* **Per-instruction-class cycle validation** (`study.validation()`): 13 classes
× 9 design points = 117 differential RTL measurements against the closed-form
model, at zero tolerance. `LUI`, `AUIPC` and `JALR` were added in v6.2 after
the compiled workloads showed that no hand-written kernel retires a jump.
* **Compiled workloads** (`results/compiled_workloads.md`): 18 Embench-IoT
benchmarks, 3.08 × 10⁸ dynamic instructions, each run to completion on the
golden ISS and each passing its own `verify_benchmark()`. The serial/parallel
CPI ratio is 13.87 (range 11.71–15.31) against 13.51 (11.8–15.1) for the hand
kernels.
* **Compiled code at RTL** (`results/compiled_spot.md`): prefixes of four
compiled binaries executed on the RTL core at all nine design points; measured
cycles equal the closed-form model exactly and the whole data memory equals the
golden ISS (36/36 runs).
* **Bound over every instruction mix** (`results/mix_envelope.md`): CPI is
linear in the class-frequency vector, so the serial/parallel ratio is bounded
exactly by [8.75, 24.25] for *any* workload — a stronger statement than any
finite benchmark suite supports.
* It is explicitly stated that the delay coefficients (t0, slope) are a
**joint calibration** to the published 171 µs and not an independent validation
(`results/validation.md` V1).


## v6.5 — register file on the die (configuration B)

* `tools/rf_system.py` — synthesizes the digit-serial register file alone and
  integrated with the core at all nine design points (`results/rf_system.json`),
  and pipelines the integrated netlists to 17 stages
  (`results/rf_system_pipelined.json`); `python3 -c "import tools.rf_system as t; t.main(); t.pipeline_all()"`.
* `tools/rf_verify.py` — five kernels at RTL and the checksum kernel at gate level
  on every integrated netlist (`results/rf_verify.json`).
* `tools/rf_numbers.py` — Tables XIII–XV of the manuscript (`results/rf_system.md`);
  `results/rf_system_clustering.md` holds Table D2.
* `results/rf_system_frontier.json` — feasibility coefficients of the integrated
  netlists (Table XIV, Fig. 2(b)).

## v6.6–6.7 — formal proofs and the yield data of [1]

* `m2d/pdk2d/formal.py`, `tools/prove_flow.py`, `tools/prove_rf_system.py` —
  formal equivalence of the whole flow (see Section 7); results in
  `results/formal.md` and `results/rf_formal.json`.
* `tools/block_yield.py` — fits (d, α) of the negative-binomial yield model to
  the register blocks of Ao *et al.* (159/224 of 144 T, 2/28 of 1,152 T),
  reports profile-likelihood intervals, the p-value of every break-even α*, and
  the per-die envelope selection at the fit (`results/block_yield.md`,
  `results/block_yield.json`, `paper/fig4_block_yield.png` = Fig. 4).
* `tools/yield_constrained.py` — width selection with a minimum die-yield
  constraint (designs with exp(−dT) < Y_min are dropped before the envelope is
  taken), solved exactly between all pairwise boundaries and feasibility
  limits, for both configurations, readings, clocks and metrics
  (`results/yield_constrained.md`; Section VI-C, VI-E and Table XVI).
* Table numbering follows the v22 manuscript: the ABC cross-check is Table A2,
  the effective wire factor Table C1, configuration-B clustering Table D2.
* `paper/` — manuscript text (`manuscript_v22.md`, exported from the
  submitted .docx) and figure scripts (Fig. 2: `make_fig2.py`, Fig. 3:
  `make_fig3.py`, Fig. 4: `tools/block_yield.py --fig`).
