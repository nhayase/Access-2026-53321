import json, sys, csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import ListedColormap, BoundaryNorm

root = sys.argv[1]
order = [(1, "ripple"), (2, "ripple"), (4, "ripple"), (8, "ripple"), (8, "prefix"),
         (16, "ripple"), (16, "prefix"), (32, "ripple"), (32, "prefix")]
label = {(1, "ripple"): "W=1", (2, "ripple"): "W=2", (4, "ripple"): "W=4", (8, "ripple"): "W=8 r",
         (8, "prefix"): "W=8 BK", (16, "ripple"): "W=16 r", (16, "prefix"): "W=16 BK",
         (32, "ripple"): "W=32 r", (32, "prefix"): "W=32 BK"}
colors = ["#c9b2a3", "#d9a066", "#e8c170", "#a8ca58", "#468232", "#75a743", "#25562e", "#4f8fba", "#3c5e8b"]
cmap = ListedColormap(["#ffffff"] + colors)
norm = BoundaryNorm(np.arange(-1.5, len(colors) + 0.5), cmap.N)
idx = {k: i for i, k in enumerate(order)}

core = {(int(r["width"]), r["adder"]): r for r in csv.DictReader(open(f"{root}/results/study.csv"))}
cpi = {k: float(v["cpi_geomean"]) for k, v in core.items()}
# configuration A: Table X coefficients (core alone, k = 1)
A = {(1, "ripple"): (146.1, 95.0), (2, "ripple"): (159.4, 128.9), (4, "ripple"): (188.4, 143.1),
     (8, "ripple"): (234.5, 181.0), (16, "ripple"): (330.6, 254.0), (32, "ripple"): (526.1, 384.4),
     (8, "prefix"): (188.8, 153.9), (16, "prefix"): (214.2, 185.0), (32, "prefix"): (239.2, 207.9)}
TA = {k: int(v["transistors"]) for k, v in core.items()}
# configuration B: integrated netlists
fr = json.load(open(f"{root}/results/rf_system_frontier.json"))
B = {(r["width"], r["adder"]): (r["D0"], r["D1_k1"]) for r in fr}
sysT = {(r["width"], r["adder"]): r["transistors"] for r in json.load(open(f"{root}/results/rf_system.json")) if r["what"] == "system"}

gws = np.logspace(-1, 1, 241); gts = np.logspace(-1, 1, 241)
fig, axes = plt.subplots(1, 2, figsize=(10, 4.4))
for ax, coeffs, T, title in ((axes[0], A, TA, "(a) register file off the die (configuration A)"),
                             (axes[1], B, sysT, "(b) register file on the die (configuration B)")):
    Z = np.full((len(gts), len(gws)), -1.0)
    for i, gt in enumerate(gts):
        for j, gw in enumerate(gws):
            best = None
            for k, (D0, D1) in coeffs.items():
                if gt * (D0 + D1 * gw) <= 1000.0 and (best is None or (cpi[k], T[k]) < (cpi[best], T[best])):
                    best = k
            if best is not None:
                Z[i, j] = idx[best]
    ax.pcolormesh(gws, gts, Z, cmap=cmap, norm=norm, shading="nearest", rasterized=True)
    for k, (D0, D1) in coeffs.items():
        ax.plot(gws, 1000.0 / (D0 + D1 * gws), lw=0.7, color="k", alpha=0.55)
    ax.plot([1], [1], marker="*", ms=13, color="crimson", mec="k", zorder=5)
    ax.annotate("2025 MoS$_2$", (1, 1), textcoords="offset points", xytext=(6, 6), fontsize=8.5)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(0.1, 10); ax.set_ylim(0.1, 10)
    ax.set_xlabel(r"wire penalty $\gamma_w$ (2025 MoS$_2$ = 1)")
    ax.set_title(title, fontsize=9.5)
axes[0].set_ylabel(r"device-delay penalty $\gamma_t$ (2025 MoS$_2$ = 1)")
handles = [mpatches.Patch(color="#ffffff", ec="0.6", label="infeasible")] + \
          [mpatches.Patch(color=colors[idx[k]], label=label[k]) for k in order]
axes[0].legend(handles=handles, fontsize=7, loc="lower left", framealpha=0.9)
fig.tight_layout()
fig.savefig("/home/claude/fig2_feasibility.png", dpi=300)
# staircase limits for the text
for name, coeffs in (("A", A), ("B", B)):
    print(name, "gt limits at gw=1:", {label[k]: round(1000 / (D0 + D1), 2) for k, (D0, D1) in coeffs.items()})
    print(name, "gw limits at gt=1:", {label[k]: round((1000 - D0) / D1, 2) for k, (D0, D1) in coeffs.items()})
