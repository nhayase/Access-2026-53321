Date of publication xxxx 00, 0000, date of current version xxxx 00, 0000.

Digital Object Identifier 10.1109/ACCESS.2024.Doi Number

Datapath Width Design Space of 32-Bit RISC-V Processors for 2D Semiconductor Logic

Naoki Hayase<sup>1</sup>

<sup>1</sup>Center for EUV lithography, LASTI, University of Hyogo, NewSUBARU synchrotron radiation facility, Ako-gun Kamigori Kouto 1-1-2, Hyogo 678-1205, Japan

Corresponding author: N. Hayase (e-mail: <hayase@lasti.u-hyogo.ac.jp>).

This work was supported in part by the Hyogo Earthquake Memorial 21st Century Research Institute, the Hyogo Foundation for Science and Technology, the Tanaka Kikinzoku Memorial Foundation, the Takahashi Industrial and Economic Research Foundation, and the Foundation of Kinoshita Memorial Enterprise.

**ABSTRACT** The first 32-bit RISC-V processor on a two-dimensional (2D) semiconductor, 5,931 MoS₂ transistors in enhancement/depletion NMOS, processes one bit per clock cycle. This work determines when such a processor should use a wider datapath. A digit-serial RV32I core spanning 1 to 32 bits with ripple and Brent–Kung carry is mapped onto a model calibrated to the published process, every mapping, buffering, and pipelining step is proved formally, and every design point executes a program at gate level, with the register file off and on the die. At 1 kHz the 32-bit core delivers 13.5× the throughput at 5.2–5.5× lower energy per instruction for 2.45–2.60× the transistors; with the 17-stage logic-depth limit of the process enforced as a hard constraint, the advantages become 6.76× and 1.87×. Bit-serial execution therefore pays only through yield, or in static energy when throughput is fixed and power gating is unavailable. The crossover is a defect density: 249 (delay-budget reading) or 75 (hard-constraint reading) defects per million transistors. The yield data of the fabricated process place it beyond both boundaries, in a regime where every design has a die yield below 1%; under a 10% die-yield constraint, bit-serial execution is selected only where every wider design fails it, at 141–220 or 67–149 defects per million transistors, and in windows under 2 per million when the register file is on the die. Coefficient tables and a four-step procedure locate other device-count-limited technologies.

**INDEX TERMS** bit-serial processing, datapath width, defect density, design space exploration, monolithic three-dimensional integration, parallel-prefix adder, RISC-V, two-dimensional semiconductors.

1.  INTRODUCTION

In 2025, a RISC-V microprocessor built from 5,931 MoS2 transistors was reported, made feasible by serializing a 32-bit architecture \[1\]. A bit serial datapath processes one bit per clock cycle and requires 32 serial steps to traverse a 32-bit word. The premise of that design is that serialization minimizes transistor count and static power, which are the binding constraints of a device-count-limited NMOS technology. The chip demonstrates the potential of two-dimensional (2D) integrated circuits.

2D semiconductors are maturing toward complementary field-effect transistor (CFET) logic and monolithic three-dimensional (M3D) integration \[2\]–\[16\], while the physical parameters that determine processor architecture, including device delay, interconnect load, integration density, leakage, and defect density, continue to evolve. The optimal architecture for a 2D technology therefore depends on its position in this parameter space. The key question is where the optimal datapath width shifts from bit serial to parallel.

A rigorous evaluation of this problem requires four elements: (i) a family of cores that differ only in datapath width, making width a controlled variable, (ii) a synthesis flow whose area, delay, and power models are tied to a fabricated 2D process rather than a silicon standard-cell library, (iii) verification sufficient to support architectural conclusions without new silicon, and (iv) a systematic sweep of physical parameters with boundaries that can be evaluated for other technologies \[1\], \[17\]. This work provides all four through M2D, a Python-based RISC-V core derived from Minerva \[18\], and a design-space exploration that evaluates the datapath width within a defined set of candidate designs, an objective function, and a fixed implementation flow.

1\) **The crossover and its location.** At the 2025 process point a 32-bit datapath is favored on feasibility, throughput, and fixed-clock energy, and, at a fixed clock, yield is the only axis that selects bit-serial execution; the crossover is therefore a defect density, given in closed form under both readings of the 17-stage rule (Section VII).

2\) **Closed-form selection boundaries.** Feasibility and Poisson yield boundaries are closed-form, with tabulated coefficients and sensitivities (Tables IX–XI), so that another process can be located without rerunning the flow.

3\) **Depth compliance and the register file on the die.** Every design point is also implemented as a netlist with no path longer than 17 stages and proved equivalent to the original (Section V), and the register file is evaluated on the die as well as off it (Section VI-E), so that every conclusion is stated for both readings of the 17-stage rule and both register-file configurations.

Section II reviews prior work; Sections III–V present the method, the 2025 operating point, and the 17-stage-compliant netlists; Sections VI and VII construct the map and the procedure for using it; Section VIII lists the limitations, and Appendices A–D hold the supporting details.

2.  RELATED WORK

    A. PROCESSORS ON 2D SEMICONDUCTORS

Integrated circuits on MoS<sub>2</sub> progressed from a few transistors \[8\], \[9\] through a 1-bit microprocessor of 115 transistors \[2\], wafer-scale fabrication optimized by machine learning \[4\], and gigahertz-class small circuits \[5\], to the 5,931-transistor RV32-WUJI \[1\]. Logic-in-memory on atomically thin channels \[11\] points to the same pressure on device count from another direction. A one-instruction-set computer of more than 2,000 transistors \[3\] followed \[1\] in the same year; it is built by heterogeneous integration of n-type MoS<sub>2</sub> and p-type WSe<sub>2</sub> transistors, operates below 3 V at up to 25 kHz, and is the first system-scale 2D processor in complementary rather than ratioed NMOS logic. Every system-scale 2D processor reported to date is a single fabricated point, and each resolves the same device-count budget by an extreme architectural choice: bit-serial execution of a full 32-bit instruction set \[1\], \[2\], or reduction of the instruction set to one instruction \[3\]. Table I places this work against them: the fabricated works establish points, and the device-level benchmarking methodology of \[17\] compares devices on fixed circuits; this work adds no measurement and establishes the boundaries between widths on a model calibrated to \[1\].

TABLE I

SCOPE OF THIS WORK AGAINST THE FABRICATED 2D PROCESSORS AND THE BENCHMARKING METHODOLOGY IT BUILDS ON (REPORTED VALUES AS PUBLISHED)

| **work**     | **technology, logic**                             | **devices**    | **datapath, ISA**                                                   | **clock**                           | **establishes**                                                                    |
|--------------|---------------------------------------------------|----------------|---------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------|
| \[2\] (2017) | MoS<sub>2</sub> NMOS                              | 115            | 1-bit custom                                                        | kHz                                 | first 2D microprocessor (a point)                                                  |
| \[1\] (2025) | MoS<sub>2</sub> E/D NMOS, 25-cell library         | 5,931          | bit-serial RV32I, register file off the die                         | 1 kHz                               | first 32-bit 2D processor (a point); the process model of this work                |
| \[3\] (2025) | MoS<sub>2</sub>/WSe<sub>2</sub> complementary     | \>2,000        | one-instruction-set computer                                        | ≤25 kHz                             | first complementary 2D processor (a point)                                         |
| \[17\]       | device-agnostic                                   | –              | fixed benchmark circuits                                            | –                                   | device-level comparison methodology                                                |
| \[19\]       | FPGA soft core                                    | –              | bit-serial RV32I                                                    | –                                   | reference microarchitecture of \[1\] and of M2D                                    |
| this work    | model of \[1\]: 2D_NMOS_lib, fan-out 4, 17 stages | 10,474–212,955 | W = 1–32, ripple and prefix carry, register file off and on the die | 1 kHz; f<sub>max</sub> extrapolated | selection boundaries between widths (feasibility, yield, energy) and the crossover |

B. SERIAL AND DIGIT-SERIAL ARCHITECTURES

Bit-serial computing has a long history in VLSI \[20\], and the digit-serial family that interpolates between it and parallel arithmetic was formalized in \[21\]. RISC-V \[22\] is the usual vehicle for such experiments on device-count-limited technologies, down to instruction-subset processors on flexible metal-oxide circuits \[23\]. The SERV core \[19\] revived bit-serial RISC-V and is the direct ancestor of the RV32-WUJI microarchitecture \[1\] and of the core used here. Width-scalable derivatives exist: QERV \[24\] widens SERV to 4 bits, FazyRV \[25\] scales an RV32I core to 1, 2, 4, or 8 bits, FlexiBits \[26\] builds 1-, 4-, and 8-bit cores on a flexible IGZO process and reports 2.65–3.50× better energy efficiency per workload execution, and SAILOR \[27\] makes the datapath configurable from 1 to 32 bits. These works vary the width within FPGA, silicon, or flexible metal-oxide technologies. This work adds what they do not provide: a cost model of 2D enhancement/depletion NMOS, in which static power dominates and the 17-stage cascade limit constrains depth (Section V); all widths to 32 bits with both carry schemes in one flow; defect density as an axis with closed-form boundaries placed against measured yields (Section VI); and the register file on and off the die. The width-parameterized core itself is not claimed as a contribution.

C. PARALLEL-PREFIX ADDITION

The trade-off between ripple and prefix carry is classical \[28\], \[29\]–\[31\]. What changes on a 2D platform is the coefficient regime, not the structure: at an intrinsic stage delay of 4.06 µs and an input capacitance of 2.5 pF per pin, logic depth is expensive and wire capacitance is cheap. Brent–Kung \[28\] is used because, among the classical prefix networks, it minimizes fan-out and wiring at the price of two extra levels, which is the right bias for a library with a fan-out limit of four. Kogge–Stone \[29\] and Sklansky \[30\] trade those resources for depth.

D. WIRES, RENT'S RULE, M3D, AND CFETS

Average wirelength follows Donath \[32\] with Rent parameters \[33\], \[34\]. Monolithic 3D integration of emerging devices was demonstrated in the N3XT program \[13\], \[35\] and analyzed at system level in \[36\]; monolithic and heterogeneous 3D integration of 2D materials has its own demonstrations \[14\], \[15\], and complementary stacking of 2D channels in CFET form is under development \[16\]. This work uses these only as parameter axes (tier count *k* and static power *p*<sub>s</sub>); every scaling assumption is labeled as such and enters a sweep.

E. YIELD-DRIVEN ARCHITECTURE SELECTION

Yield statistics, yield models, and defect clustering are classical \[37\]–\[39\]. On a device-count-limited technology, FlexiCores \[40\] measured die yield against width on a flexible IGZO process (81% for a 4-bit processor, lower for the 8-bit version). This article makes defect density an axis of the map and places the 2025 process on it from the yield data of \[1\]: the per-transistor yield and two register blocks of 144 and 1,152 transistors on one wafer, which together also constrain the negative-binomial clustering parameter \[38\] (Section VI-C).

F. LOGIC SYNTHESIS AND TECHNOLOGY MAPPING

No process design kit for a 2D semiconductor process that commercial synthesis tools accept was available to this study. The mapper, the analyzer, and the design-rule checks of Section III-C were written for this study; the only delegated step is the lowering from register-transfer level, which goes to yosys \[41\]. The structural covering is DAG matching in the sense of \[42\]; the independent mapper of the cross-check is the AND-inverter-graph rewriting flow of ABC \[43\], and the equivalence proofs of this flow use the structural hashing and SAT of combinational equivalence checking \[44\]. The depth-compliant netlists of Section V are related to retiming \[45\] but divide each architectural cycle into several physical periods and leave cycle counts unchanged. Switching activity is the standard vehicle for power estimation \[46\]; here it is measured on the mapped netlist during program execution rather than assumed.

3.  METHODOLOGY

    A. WIDTH-PARAMETERIZED CORE

M2D is a width-parameterized digit-serial RV32I core (Fig. 1). One microarchitecture covers the widths *W* = 1, 2, 4, 8, 16, and 32 and two carry schemes. Only the hatched blocks scale with *W*; the finite-state machine, the digit counter, the program counter, the instruction register, and the four inter-digit flags are width-invariant. The register file and both memories are external, as in \[1\].

<img src="media/image2.png" style="width:6.67774in;height:3.62235in" />

1.  The M2D core. One microarchitecture covers digit widths W = 1 to 32; only the hatched blocks (buffer registers, data register, and the digit ALU with its four W-bit adders: two ALU adders, the comparator, and the program-counter adder) scale with W. The register file and both memories are external, as in the fabricated chip; Section VI-E also evaluates the register file on the die.

M2D derives from the Minerva RV32I soft processor \[18\] and implements RV32I \[22\] without FENCE, ECALL, and the CSR instructions, as in \[1\]. It is a finite-state machine of two stages per digit that processes *D* = 32/*W* digits per word operation. All width-dependent state is parameterized: the ALU carry, the program-counter carry, the comparison flags, and the shift counters. The program counter is a rotating shift register, which removes the 32-to-1 read multiplexer and the 32-way write demultiplexer at small *W* and degenerates to an ordinary parallel register at *W* = 32. The register file has three data ports of *W* bits plus index lines.

One-stage instructions take *D* + 2 cycles (ALU-immediate, ALU-register, LUI, AUIPC, JAL). Two-stage instructions take 2*D* + 2 cycles (branches, comparisons, shifts, JALR; JALR needs an addition before the fetch can be redirected). Loads take 2*D* + 3 cycles and stores *D* + 3. Right shifts at *W* = 1 add the shift amount, because that design point uses the transistor-minimal pre-shift scheme of \[1\] instead of a barrel shifter. Equation (1) collects the class costs:

$$\begin{array}{r}
c_{1} = D + 2,\quad c_{2} = 2D + 2,\quad c_{ld} = 2D + 3,\quad c_{st} = D + 3.\#(1)
\end{array}$$

The cycle count of a program follows from the retired class counts *n*<sub>c</sub> and the summed right-shift amounts:

$$\begin{array}{r}
N_{cyc} = \sum_{c}^{}n_{c}\, c_{c}(W) + \lbrack W = 1\rbrack\sum_{r}^{}{sh}_{r},\#(2)
\end{array}$$

where the bracket equals 1 at *W* = 1 and 0 otherwise. The RTL is the source of (1) and (2), and Appendix A validates every count at zero tolerance at every design point. The Amaranth HDL \[47\] source is close to 700 lines.

B. ADDERS

Both carry schemes are structural gate-level implementations so that the synthesis flow sees identical primitives: a ripple chain of *W* full adders with a carry depth of *W*, and a Brent–Kung prefix tree \[28\] with 2⌈log<sub>2</sub> *W*⌉ − 1 carry levels. Behavioral addition is avoided because yosys would expand it through its own carry-lookahead structure and reintroduce the variable under study. Neither scheme is fan-out-legal by construction (the final carry stage of the prefix tree drives *W* gates), so both pass through the same buffering pass, and the transistor cost of that legalization is included in every reported number.

C. SYNTHESIS FLOW ONTO THE FABRICATED-PROCESS MODEL

The flow is Python-based and uses yosys for the lowering of the RTL \[41\]. It maps to the 2D_NMOS_lib of \[1\], which holds 25 cells (enhancement- and depletion-mode NMOS at *V*<sub>dd</sub> = 4 V, from INV through the NAND, NOR, AOI, and OAI families to MUX2, XOR2, and an 18-transistor flip-flop). Seven further cells characterized in \[1\] have a published noise margin below 5% of *V*<sub>dd</sub> and are excluded. yosys lowers Amaranth RTLIL to primitive gates; a structural DAG-covering mapper \[42\] covers them with library cells through constant propagation, AOI/OAI covering, and associative tree balancing. Fan-out is legalized to at most four by inverter trees of even level count. Static timing uses the linear stage-delay model

$$\begin{array}{r}
t = t_{0} + s\, C_{load},\#(3)
\end{array}$$

with *t*<sub>0</sub> = 4.06 µs, *s* = 0.6 µs/pF, and an input capacitance *C*<sub>pin</sub> = 2.5 pF per pin. The load of a stage driving *F* pins is *C*<sub>pin</sub>*F*, saturating at *F*<sub>max</sub> = 4; the saturation has no effect on the legalized netlists of this flow and makes the reported delay of an unlegalized netlist an optimistic bound. The path delay adds the clock-to-output stage of the launching flip-flop, and its reciprocal is the maximum frequency:

$$\begin{array}{r}
f_{\max} = 1/t_{path},\quad\quad t_{path} = t_{clkQ} + \sum_{i \in P}^{}t_{i},\#(4)
\end{array}$$

with *t*<sub>clkQ</sub> = *t*<sub>0</sub> + *s* *F*<sub>max</sub> *C*<sub>pin</sub> = 10.06 µs. Static power follows the transistor count *T*:

$$\begin{array}{r}
P_{stat} = p_{s}\, T,\#(5)
\end{array}$$

with *p*<sub>s</sub> = 72.67 nW per transistor (0.431 mW over 5,931 transistors \[1\]). The uniform per-transistor weighting is an assumption (Section VIII).

Reference \[1\] publishes one delay number, so the calibration fixes one combination of the two delay coefficients:

$$\begin{array}{r}
t_{0} + F_{\max}C_{pin}\, s = 10.06\ \mu s.\#(6)
\end{array}$$

The split between *t*<sub>0</sub> and *s* is unidentified. Its consequences follow in closed form: a design of *n* stages (Table IX) with measured delay *t* has, under any alternative split (*t*<sub>0</sub>′, *s*′) on the line of (6), the delay

$$\begin{array}{r}
t' = nt_{0}' + \frac{s'}{s}\,\left( t - nt_{0} \right).\#(7)
\end{array}$$

Everything stated at the fixed 1 kHz clock is invariant under the split, because a fixed clock removes the delay from both the throughput and the energy expression. The extrapolated maximum-frequency columns are not invariant, and the sensitivity is small: sweeping the split over the admissible line moves the maximum-frequency defect ladder from 41/92/198 to a band between 43/86/185 and 39/95/204 defects per million transistors, and the published anchor stays 3.9–4.3× above the bit-serial boundary. Two statements depend on the split and are flagged where made: *W* = 32 with ripple carry loses 1 kHz feasibility for *s*′ below 0.409 µs/pF, and the extrapolated energy optimum at maximum frequency exchanges between *W* = 16 and *W* = 32 with prefix carry (the two differ by 0.5% in Table IV). The ratio *t*<sub>0</sub>/*s* = 6.77 pF is the self-load implied by the intrinsic term and corresponds to close to 2.7 input pins, which is the right order for a cell of this library.

Every mapping and buffering step is proved formally. The two netlists of a step are built into one and-inverter graph with structural hashing, and every primary output and flip-flop data input whose two literals still differ is proved equal by a SAT solver for all input and state values \[44\]. The proof refutes all of 20 random single-cell mutants at every design point (Appendix A).

D. VERIFICATION STACK

The verification stack has five layers, summarized here and detailed in Appendix A with Table A1, which records which layer was run at which design point.

**V1, calibration (no evidential weight).** The calibration of Section III-C (Appendix A) fixes the units of the model and validates nothing.

**V2, cycle-exact class validation.** The per-class cycle counts of (1) are measured at RTL as cycle-count differences between programs for all thirteen retirement classes at all nine design points: 117 of 117 checks match at zero tolerance.

**V2b, gate-level program execution.** One complete program (the checksum kernel) executes on each of the nine mapped and legalized netlists, finishing in the RTL cycle count (9,393 cycles at *W* = 1 down to 701 at *W* = 32) and producing the golden checksum of the instruction-set simulator (ISS). This run also supplies the measured switching activity and pad activity.

**V2c, independent mapper cross-check.** The same RTLIL passes through the ABC mapper bundled with yosys \[43\] for three representative netlists, each legalized by the same fan-out pass and re-verified against the netlist ABC emitted (Table A2). Both mappers preserve the ordering between the bit-serial and 32-bit design points, the only widths mapped by both; the ordering of ripple against prefix carry at *W* = 32 is mapper-dependent (Section IV-A).

**V3, chip-level gap.** Against the fabricated *W* = 1 chip, this flow produces 1.77× the transistors (10,474 against 5,931) and 2.0× the logic depth (34 stages against 17). No mapper available to this study meets the 17-stage budget of the hand-optimized chip, which is why Section V implements netlists that meet it by construction rather than by assumption.

E. WORKLOADS AND THE CLOSED-FORM CPI MODEL

Two workload sets are used. The first is five hand-written kernels (checksum, memcpy, softmul, sort, popcount) with 60 to 1,324 dynamic instructions each, short enough for cycle-accurate RTL simulation at all nine design points. The second is eighteen of the nineteen Embench-IoT benchmarks \[48\] compiled for RV32I at −Os (3.1 × 10<sup>8</sup> dynamic instructions in total, every run self-verified on the golden ISS). Because the per-class cycle counts are validated at zero tolerance, cycles per instruction (CPI) is a closed-form function of the dynamic class mix *f*<sub>c</sub> = *n*<sub>c</sub>/*N* in the sense of the classical performance decomposition \[49\]:

$$\begin{array}{r}
CPI(W) = \sum_{c}^{}f_{c}\, c_{c}(W) + \lbrack W = 1\rbrack\,\frac{1}{N}\sum_{r}^{}{sh}_{r}.\#(8)
\end{array}$$

The headline numbers use the geometric mean of the five kernels, which agrees with all 45 cycle-accurate measurements to within 0.005 CPI. Appendix B gives the compiled mixes, the RTL spot-checks of the model on compiled prefixes, and the exact bound over all instruction mixes.

F. WIRE MODEL

The per-pin load is modeled as

$$\begin{array}{r}
C_{eff} = C_{G} + \gamma_{w}\, c_{w}\,\frac{L(N)}{\sqrt{k}},\quad\quad L(N) = aN^{p - 1/2},\#(9)
\end{array}$$

with *N* the cell count, *L*(*N*) the Donath average wirelength in gate pitches \[32\], Rent exponent *p* = 0.60, prefactor *a* = 0.9 \[33\], \[34\], device input capacitance *C*<sub>G</sub> = 0.1 pF, *k* the tier count, and *γ*<sub>w</sub> the wire-technology factor. The wire capacitance per gate pitch, *c*<sub>w</sub> = 1.27 pF, is calibrated so that the single-layer *W* = 1 design reproduces the measured 2.5 pF per pin. The effective wire factor *λ*<sub>eff</sub> = *C*<sub>eff</sub>/*C*<sub>pin</sub> (Table C1) is a derived quantity. Appendix C states three caveats of this model and shows that none of the orderings of this article changes under Rent exponents from 0.5 to 0.75.

G. EXTERNAL-INTERFACE COST MODEL

Without an explicit account, the parallel designs would receive wide interfaces at no cost. Five items are charged (Section IV-D): the external pin count *N*<sub>io</sub>(*W*); pad energy from measured pad-bit toggles, *E*<sub>io</sub> = *n*<sub>io</sub> *C*<sub>pad</sub> *V*<sub>dd</sub><sup>2</sup>; pad delay, which adds two pad crossings to every critical path; pad yield, which charges *ρ* transistor-equivalents of defect exposure per pin, *T*<sub>eff</sub> = *T* + *ρ* *N*<sub>io</sub>; and memory bandwidth, measured by repeating all 45 CPI measurements with three wait states per bus transaction (an 8-bit external bus serving 32-bit words). The pad capacitance *C*<sub>pad</sub> = 10 pF equals the maximum legal load of the library.

4.  THE 2025 OPERATING POINT

    A. SYNTHESIS

Table II reports the nine synthesized design points after fan-out legalization, with zero violations at every point. Serialization saves a factor of 2.45 to 2.60 in transistors (10,474 against 25,679 for ripple carry and 27,195 for prefix carry at *W* = 32), not the factor of 32 that the cycle cost would suggest: the control, the program counter, the instruction register, and the sequential state are width-invariant, and the flip-flop count falls from 145 to 135 as the digit counters shrink. Logic depth tells the opposite story and is where the carry scheme decides everything. From *W* = 1 to *W* = 32 the ripple datapath deepens from 34 to 125 stages; the prefix datapath reaches *W* = 32 at 56 stages, 1.6× the bit-serial depth. No design point meets the 17-stage budget of the fabricated chip (Section V). Every design point meets 1 kHz timing.

TABLE II

SYNTHESIS RESULTS FOR THE NINE DESIGN POINTS (POST-BUFFERING, FAN-OUT ≤ 4, ZERO VIOLATIONS)

| **W** | **adder** | **cells** | **DFF** | **T (NMOS)** | **depth (pre-buf.)** | **delay (µs)** |
|-------|-----------|-----------|---------|--------------|----------------------|----------------|
| 1     | ripple    | 1,696     | 145     | 10,474       | 34 (29)              | 241.1          |
| 2     | ripple    | 2,534     | 139     | 15,705       | 37 (30)              | 283.3          |
| 4     | ripple    | 2,664     | 138     | 16,359       | 44 (35)              | 325.2          |
| 8     | ripple    | 2,937     | 137     | 17,748       | 55 (46)              | 405.9          |
| 16    | ripple    | 3,510     | 136     | 20,649       | 78 (69)              | 566.7          |
| 32    | ripple    | 4,526     | 135     | 25,679       | 125 (114)            | 874.6          |
| 8     | prefix    | 2,978     | 137     | 17,979       | 44 (35)              | 334.2          |
| 16    | prefix    | 3,646     | 136     | 21,327       | 50 (39)              | 385.6          |
| 32    | prefix    | 4,831     | 135     | 27,195       | 56 (41)              | 426.4          |

Depth is given after buffering, with the pre-buffering value in parentheses. Delay is the critical path under (3)–(4).

Table A2 (Appendix A) maps the same RTLIL with ABC \[43\] at three points. Against legalized ABC this flow carries 1.48, 1.44, and 1.58× the transistors; a width-independent overhead cancels from every serial-to-parallel ratio, so the ±5% spread is the mapper uncertainty of those ratios. The yield boundaries depend on a difference of transistor counts and move with the mapper: ABC places the direct *W* = 32-to-bit-serial boundary 1.4–1.7× higher (180 and 132 against 122 and 86 ppm/T at maximum frequency with prefix and ripple carry, 258 and 241 against 156 and 171 at 1 kHz) and makes the *W* = 32 prefix netlist 3.9% smaller than the ripple one, so the *W* = 32 entries labeled ripple in the 1 kHz delay-budget ladders (Tables X and XVI, Fig. 2(a)) would carry prefix carry under ABC. The ABC gate set omits the three-input NAND and NOR cells and the larger AOI/OAI cells, so *q* = 1.48 is a lower bound on what a production mapper would achieve (Section VI-C). The ripple-to-prefix delay ratio at *W* = 32 is 1.48 under ABC and 2.05 here, so the adder conclusion of Section IV-E is mapper-independent.

B. WORKLOAD BEHAVIOR

Table III gives the cycle-accurate CPI of all nine design points on the five kernels, with results asserted identical across design points. The serial-to-parallel CPI ratio runs from 11.8 to 15.1 across kernels with a geometric mean of 13.5; the ratio is robust to the instruction mix because the digit count *D* = 32/*W*, common to every class, dominates it. The adder choice leaves CPI untouched by construction. On the eighteen compiled Embench-IoT benchmarks (Appendix B, Table B1) the geometric-mean ratio is 13.87 with a range of 11.71 to 15.31, 2.7% above the kernels with a near-identical spread. Because CPI is linear in the class-frequency vector, the ratio is a ratio of linear forms on the probability simplex and attains its extrema at single-class programs: the exact envelope over all instruction mixes at zero-wait memory is 8.75 (stores only) to 24.25 (right shifts by 31 only).

TABLE III

CYCLE-ACCURATE CPI PER WORKLOAD (ZERO-WAIT MEMORY)

| **W** | **adder** | **checksum** | **memcpy** | **softmul** | **sort** | **popcount** | **geo-mean** |
|-------|-----------|--------------|------------|-------------|----------|--------------|--------------|
| 1     | ripple    | 47.92        | 46.48      | 55.52       | 53.84    | 46.96        | 50.00        |
| 2     | ripple    | 24.70        | 24.52      | 28.68       | 28.07    | 24.39        | 26.00        |
| 4     | ripple    | 13.43        | 13.55      | 15.35       | 15.18    | 13.20        | 14.11        |
| 8     | ripple    | 7.80         | 8.06       | 8.68        | 8.74     | 7.60         | 8.16         |
| 16    | ripple    | 4.98         | 5.31       | 5.35        | 5.52     | 4.80         | 5.19         |
| 32    | ripple    | 3.58         | 3.94       | 3.68        | 3.91     | 3.41         | 3.70         |
| 8     | prefix    | 7.80         | 8.06       | 8.68        | 8.74     | 7.60         | 8.16         |
| 16    | prefix    | 4.98         | 5.31       | 5.35        | 5.52     | 4.80         | 5.19         |
| 32    | prefix    | 3.58         | 3.94       | 3.68        | 3.91     | 3.41         | 3.70         |

The adder leaves CPI unchanged.

C. THROUGHPUT AND ENERGY UNDER THREE OPERATING ASSUMPTIONS

The fabricated process operates at 1 kHz and the delay model is anchored there, so the primary results stand at that clock; they are model evaluations calibrated to the published process values, not measurements of parallel 2D circuits. Throughput is thr = *f*/CPI, and because static power dominates (*p*<sub>s</sub> = 72.67 nW per transistor), the energy per instruction is the static power times the time per instruction:

$$\begin{array}{r}
E = p_{s}\, T\,\frac{CPI}{f}.\#(10)
\end{array}$$

Table IV reports the fixed-clock point and, as a reference, the operation of each design at its own maximum frequency. The maximum-frequency columns use the linear delay model up to 5.1× beyond the calibration path of 171 µs and carry the label *extrapolated*.

TABLE IV

PERFORMANCE AND ENERGY (GEOMETRIC-MEAN CPI)

| **W** | **adder** | **f<sub>max</sub> (Hz)** | **instr/s at f<sub>max</sub>** | **E/instr (µJ) at f<sub>max</sub>** | **instr/s at 1 kHz** | **E/instr (µJ) at 1 kHz** |
|-------|-----------|--------------------------|--------------------------------|-------------------------------------|----------------------|---------------------------|
| 1     | ripple    | 4,147.7                  | 82.9                           | 9.175                               | 20.0                 | 38.05                     |
| 2     | ripple    | 3,530.1                  | 135.7                          | 8.405                               | 38.5                 | 29.67                     |
| 4     | ripple    | 3,075.0                  | 217.9                          | 5.457                               | 70.9                 | 16.78                     |
| 8     | ripple    | 2,463.9                  | 301.8                          | 4.274                               | 122.5                | 10.53                     |
| 16    | ripple    | 1,764.5                  | 340.1                          | 4.413                               | 192.8                | 7.79                      |
| 32    | ripple    | 1,143.4                  | 309.2                          | 6.035                               | 270.4                | 6.90                      |
| 8     | prefix    | 2,992.2                  | 366.5                          | 3.566                               | 122.5                | 10.67                     |
| 16    | prefix    | 2,593.6                  | 499.9                          | 3.100                               | 192.8                | 8.04                      |
| 32    | prefix    | 2,345.1                  | 634.2                          | 3.116                               | 270.4                | 7.31                      |

The f<sub>max</sub> columns are extrapolated; the 1 kHz columns are the evaluation at the fabricated clock with the model calibrated to the published process values.

At the fixed 1 kHz clock the parallel core delivers 13.5× the throughput at 5.2–5.5× lower energy per instruction for 2.45–2.60× the transistors: the CPI ratio overwhelms the transistor ratio wherever static power dominates. The intermediate widths *W* = 2 and 4 are dominated at this operating point. In the extrapolated ordering, *W* = 32 with prefix carry reaches 2,345 Hz and 634 instructions per second, 7.7× the bit-serial value; ripple carry at *W* = 32 forfeits half of the achievable frequency (Section IV-E).

The energy ordering depends on an operating assumption that (10) makes explicit; Table V gives the three cases. Under a fixed clock, or under race-to-sleep with power gating, the parallel core is charged static power for fewer cycles and wins by the CPI ratio divided by the transistor ratio. Under iso-throughput operation without power gating, the application fixes the instruction rate (here the bit-serial 20 instructions per second, which the 32-bit ripple core meets at 74 Hz), the time per instruction is the same for both cores, (10) reduces to *E* ∝ *T*, and the bit-serial core wins by the transistor ratio, 2.45–2.60×.

TABLE V

ENERGY PER INSTRUCTION UNDER THREE OPERATING ASSUMPTIONS

| **assumption**            | **W = 1 ripple** | **W = 32 ripple**     | **W = 32 prefix** | **W = 16 prefix** | **winner** |
|---------------------------|------------------|-----------------------|-------------------|-------------------|------------|
| fixed 1 kHz clock         | 38.05 µJ         | 6.90 µJ (5.5× better) | 7.31 µJ (5.2×)    | 8.04 µJ (4.7×)    | parallel   |
| race-to-sleep at 1 kHz    | 38.05 µJ         | 6.90 µJ               | 7.31 µJ           | 8.04 µJ           | parallel   |
| iso-throughput, no gating | 38.05 µJ         | 93.3 µJ (2.45× worse) | 98.8 µJ (2.60×)   | 77.5 µJ (2.04×)   | bit-serial |

Static power only; delay-budget netlists of Table II. The iso-throughput row clocks the parallel core down to the bit-serial throughput of 20 instr/s.

Every statement in this article that bit-serial execution is not an energy strategy is a statement under the first two assumptions. Under the third, serialization is the energy-optimal choice for the reason the designers of \[1\] gave: it minimizes the number of leaking transistors. The width map of Section VI uses throughput, which is assumption-free at a fixed clock, as its performance metric for that reason.

D. EXTERNAL-INTERFACE COSTS AND MEMORY BANDWIDTH

The external pin count grows from 193 at *W* = 1 to 282 at *W* = 32 because three register-file buses of *W* bits replace three buses of 1 bit (Table VI). Pad energy nevertheless favors the parallel design: the measured pad-bit toggles per instruction are 318 at *W* = 1 against 73 at *W* = 32, because the serial core drives few wires many times while the parallel core drives many wires once. At 10 pF the pad energies are 0.051 against 0.012 µJ per instruction, small beside the static budget and of the same sign, so no finite pad capacitance reverses the fixed-clock energy advantage. The two pad crossings leave all nine points feasible at 1 kHz.

TABLE VI

EXTERNAL-INTERFACE COSTS

| **W** | **adder** | **N<sub>io</sub>** | **pad-bit toggles/instr** | **E<sub>io</sub>/instr (µJ)** | **delay + 2 pads (µs)** | **f′<sub>max</sub> (Hz)** |
|-------|-----------|--------------------|---------------------------|-------------------------------|-------------------------|---------------------------|
| 1     | ripple    | 193                | 318.2                     | 0.051                         | 261.2                   | 3,828                     |
| 2     | ripple    | 195                | 179.6                     | 0.029                         | 303.4                   | 3,296                     |
| 4     | ripple    | 200                | 130.6                     | 0.021                         | 345.3                   | 2,896                     |
| 8     | ripple    | 211                | 103.2                     | 0.017                         | 426.0                   | 2,347                     |
| 16    | ripple    | 234                | 90.9                      | 0.015                         | 586.8                   | 1,704                     |
| 32    | ripple    | 282                | 73.2                      | 0.012                         | 894.7                   | 1,118                     |
| 8     | prefix    | 211                | 103.2                     | 0.017                         | 354.3                   | 2,822                     |
| 16    | prefix    | 234                | 90.9                      | 0.015                         | 405.7                   | 2,465                     |
| 32    | prefix    | 282                | 73.2                      | 0.012                         | 446.5                   | 2,240                     |

Measured pad activity, checksum workload, C<sub>pad</sub> = 10 pF.

Pad count does select a width, through yield. Charging *ρ* transistor-equivalents of defect exposure per external pin taxes the one resource where serialization wins. The envelope order of Section VI-B holds for *ρ* = 0, 300, and 1,000, stepping through *W* = 32, 16, 8, and bit-serial in each case; expensive pads compress every boundary toward lower defect density (the boundary at which *W* = 32 leaves the envelope moves from 41 to 12 to 4 defects per million transistors at maximum frequency) and insert a narrow *W* = 4 window between *W* = 8 and bit-serial (from 106 defects per million at *ρ* = 300). The extreme *ρ* = 1,000 corresponds to a pad ring 18× the size of the *W* = 1 core.

A second measurement of all 45 CPI values with three wait states per bus transaction compresses the serial-to-parallel CPI ratio from 13.5 to 7.3 (CPI 53.7 at *W* = 1 against 7.32 at *W* = 32). The fixed-clock energy optimum moves inward from *W* = 32 (6.90 µJ) to *W* = 16 with ripple carry (13.24 against 13.66 µJ at *W* = 32). This is a real shift of the interior optimum under slow memory; the serial-versus-parallel conclusion holds because the bit-serial core costs 3.1× the energy at 40.85 µJ and 7.3× the cycles.

E. THE ADDER QUESTION

At *W* = 32 the standalone ripple adder needs 96 mapped stages and 636.8 µs; Brent–Kung needs 20 stages and 149.8 µs for 1.38× the transistors (Table VII). At core level the prefix tree costs 5.9% more transistors and doubles the maximum frequency from 1,143 to 2,345 Hz. Could wire parasitics reverse this on a 2D platform where the spans of the prefix tree are longer? The synthesis flow charges every input pin the same load and cannot see that a Brent–Kung combine at distance *d* spans *d* bit pitches while every ripple carry wire spans about one. The exact adder graphs were therefore built with every edge annotated by its span, and the critical path evaluated under a wire capacitance *c*<sub>bit</sub> per bit pitch, *t*(*c*<sub>bit</sub>) = *t*<sub>0</sub> + *s* *c*<sub>bit</sub> *S*, where *S* is the accumulated span of the critical path: the linear regime of short wires sums the spans (*S*<sub>lin</sub>) and the distributed-RC regime of long unbuffered wires sums their squares (*S*<sub>quad</sub>). The crossover capacitance at which ripple becomes faster follows from equal delays and exists only when the prefix span exceeds the ripple span.

TABLE VII

STANDALONE ADDERS OF W BITS AND WIRE-SPAN ANALYSIS

| **W** | **adder** | **T** | **depth** | **delay (µs)** | **linear-C crossover** | **distributed-RC crossover** |
|-------|-----------|-------|-----------|----------------|------------------------|------------------------------|
| 4     | ripple    | 172   | 12        | 85.8           | none                   | 25.7 pF/pitch                |
| 4     | prefix    | 190   | 7         | 55.0           |                        |                              |
| 8     | ripple    | 344   | 24        | 164.5          | none                   | 9.68 pF/pitch                |
| 8     | prefix    | 421   | 11        | 83.2           |                        |                              |
| 16    | ripple    | 688   | 48        | 321.9          | none                   | 4.84 pF/pitch                |
| 16    | prefix    | 912   | 16        | 118.5          |                        |                              |
| 32    | ripple    | 1,376 | 96        | 636.8          | none                   | 2.62 pF/pitch                |
| 32    | prefix    | 1,895 | 20        | 149.8          |                        |                              |

Under a linear wire model the answer is no at any wire quality: the critical wire paths of both adders traverse the same *W* pitches, because the longer individual spans of the prefix tree are offset by their smaller number, so wire load adds the same delay to both. A distributed-RC regime creates a crossover at 2.62 pF per pitch for *W* = 32, which exceeds the total measured per-pin load of the process. This is a property of the Brent–Kung topology, not of prefix addition in general; a minimum-depth network such as Kogge–Stone would lengthen the critical wire path and could admit a crossover (an argument about spans, not a measurement, since neither Kogge–Stone nor Sklansky was synthesized).

5.  THE TWO READINGS OF THE 17-STAGE RULE

The fabricated chip has at most 17 logic stages between flip-flops. Reference \[1\] does not state whether this is a delay budget or a constraint on noise margin and level restoration in cascades of enhancement- and depletion-mode NMOS, and the two readings lead to different netlists, so this article evaluates both and carries both through the map.

Under the **delay-budget reading**, a 17-stage path at 171 µs uses 17% of the 1 kHz period; the deepest design point of this family uses 87%, and all nine netlists of Table II meet timing as they stand.

Under the **cascade reading**, no netlist of Table II satisfies the rule, so every design point is implemented a second time as a netlist in which no path between flip-flops exceeds 17 stages. Compliance means satisfying the three netlist-level rules that \[1\] publishes: at most 17 stages between flip-flops, fan-out at most four, and exclusion of the cells below the noise-margin threshold. Placement, routing, and electrical simulation of the NMOS cascades are outside the flow, so these netlists establish rule compliance within the model, not manufacturability. The construction is a sub-cycle pipelining that uses the cells of 2D_NMOS_lib alone and leaves the architecture and its cycle counts unchanged. A one-hot ring counter of *S* flip-flops divides each architectural cycle into *S* physical periods; every architectural flip-flop latches its next state in the last period alone, through a hold multiplexer (omitted where the sequential check below proves it unnecessary). The logic levels are divided into *S* bands of at most 17 levels by *S* − 1 cuts, a flip-flop is inserted for every crossed cut on every net driven by a logic cell, and a dynamic program places the cuts so that the register count is minimal under the band constraint. Flip-flop outputs and input pads are full-swing sources and receive no register; primary outputs hold their settled value to the end of the architectural cycle and need no balancing registers. All designs run at the compliant period

$$\begin{array}{r}
t_{c} = D_{\max}\,\left( t_{0} + sF_{\max}C_{pin} \right) = 171.02\ \mu s,\quad\quad f_{c} = 5,847\ Hz,\#(11)
\end{array}$$

and each architectural cycle takes *S* = ⌈*L*<sub>end</sub>/17⌉ physical periods, so CPI<sub>c</sub> = *S* × CPI. The transistor count of the compliant netlist is *T*<sub>c</sub> = *T* + Δ*T*<sub>pipe</sub>, counted on the netlist (pipeline registers, hold multiplexers, ring counter, and the inverters that fan-out legalization adds).

Every compliant netlist passes the analyzer of Section III-C at a logic depth of 17 with zero fan-out violations and passes the noise-margin check; its critical path per physical period runs from 136.1 to 149.6 µs against the 171.02 µs period. Each netlist is proved equivalent to its mapped netlist over one architectural cycle: for all architectural states, all pipeline-register contents, all primary inputs, and an environment that returns arbitrary values on every input whose dependencies have not yet settled, the state after *S* periods and the outputs of the last period equal one evaluation of the mapped netlist. Every architectural cycle after reset starts in ring phase 0 with arbitrary pipeline contents, so the proof covers every cycle. The same netlist with a ring of *S* − 1 phases is refuted at every point. Each netlist also executes the checksum program at gate level at sub-cycle granularity from a random initial state through reset; all nine finish in the architectural cycle count of the RTL (9,393 at *W* = 1 down to 701 at *W* = 32) and produce the golden checksum.

TABLE VIII

STRICT DEPTH COMPLIANCE AT 17 STAGES

| **W** | **adder** | **S** | **cut regs** | **hold MUX** | **T<sub>c</sub>** | **CPI<sub>c</sub>** | **instr/s** | **E/instr (µJ)** |
|-------|-----------|-------|--------------|--------------|-------------------|---------------------|-------------|------------------|
| 1     | ripple    | 2     | 198          | 134          | 15,500            | 100.0               | 58.5        | 19.26            |
| 2     | ripple    | 3     | 549          | 139          | 27,127            | 78.0                | 75.0        | 26.30            |
| 4     | ripple    | 3     | 767          | 137          | 31,703            | 42.3                | 138.1       | 16.68            |
| 8     | ripple    | 4     | 1,068        | 137          | 38,565            | 32.6                | 179.1       | 15.64            |
| 16    | ripple    | 5     | 1,953        | 135          | 57,447            | 26.0                | 225.3       | 18.53            |
| 32    | ripple    | 8     | 3,953        | 135          | 98,448            | 29.6                | 197.5       | 36.22            |
| 8     | prefix    | 3     | 822          | 137          | 34,341            | 24.5                | 238.9       | 10.45            |
| 16    | prefix    | 3     | 1,050        | 136          | 41,830            | 15.6                | 375.5       | 8.09             |
| 32    | prefix    | 4     | 1,514        | 135          | 55,960            | 14.8                | 395.1       | 10.29            |

CPI<sub>c</sub> is S times the geometric-mean CPI of Table III; throughput and energy are at the compliant clock of 5,847 Hz with the static power of (5). T<sub>c</sub> includes the ring counter and the fan-out inverters.

Three things change under the cascade reading, and Section VI carries all three into the map. First, the throughput optimum stays at *W* = 32 with prefix carry (395.1 instructions per second, 6.76× the compliant bit-serial core for 3.61× the transistors), but *W* = 16 with prefix carry is within 5% of it for 25% fewer transistors and is the energy optimum (8.09 µJ, 2.38× better than the compliant bit-serial core; *W* = 32 prefix is 1.87× better). Second, ripple carry at *W* = 32 needs 8 sub-cycles against 4 for prefix carry and 1.76× the transistors; its energy per instruction is 3.52× that of prefix carry and 1.88× that of the compliant bit-serial core. Under the cascade reading parallel-prefix carry stops being an optimization and becomes a prerequisite for a 32-bit datapath that beats bit-serial in energy. Third, the transistor gap between serial and parallel widens from 2.6× to 3.6×, which is what moves the yield boundaries in Section VI-B. Under the iso-throughput assumption the ordering again reverses, by 2.70× for *W* = 16 and 3.61× for *W* = 32 prefix. A physical clock of 1 kHz in place of 5,847 Hz scales every throughput and energy of Table VIII by one common factor and leaves every ratio unchanged.

6.  THE WIDTH MAP

The map has three axes on which the optimal width can change: the performance axes (device delay and wire load, with tier count folded in), the yield axis (defect density), and the energy axis (static power). This section gives each boundary in the form a reader with another process can evaluate.

A. FEASIBILITY BOUNDARIES IN CLOSED FORM

Under scaled technology parameters the critical path of every design is linear in two scaling factors at zero residual,

$$\begin{array}{r}
delay = \gamma_{t}\left( D_{0} + D_{1}(k)\,\gamma_{w} \right) = 1/f_{op},\#(12)
\end{array}$$

where *γ*<sub>t</sub> scales the device delay through both *t*<sub>0</sub> and *s*, *γ*<sub>w</sub> scales the wire capacitance, and the two coefficients follow from the measured delay *t* of a design with *n* stages on its critical path:

$$\begin{array}{r}
D_{0} = nt_{0} + \left( t - nt_{0} \right)\,\frac{C_{G}}{C_{pin}},\quad\quad D_{1}(k) = \left( t - nt_{0} \right)\,\frac{c_{w}L(N)}{\sqrt{k}\, C_{pin}}.\#(13)
\end{array}$$

Every feasibility boundary in Fig. 2(a) is therefore the closed-form curve of (12), reproducible from the coefficients of Table IX with no rerun of the flow; a change of operating frequency rescales the *γ*<sub>t</sub> axis and nothing else. The stage count in Table IX includes the clock-to-output stage of the launching flip-flop and exceeds the logic depth of Table II by one. The sum *D*<sub>0</sub> + *D*<sub>1</sub> at *γ*<sub>w</sub> = 1 carries the architecture-dependent wire factor of Table C1; it coincides with the measured delay of Table II at *W* = 1, where that factor is 1.000 by calibration, and exceeds it elsewhere by 1.8 to 4.9%, the most at *W* = 32 with prefix carry. Table IV uses the measured delays; Fig. 2 and this section use (12). Fig. 2(b) repeats the map with the register file on the die (Section VI-E).

TABLE IX

FEASIBILITY-FRONTIER COEFFICIENTS OF (12)–(13) IN MICROSECONDS

| **W** | **adder** | **stages** | **D<sub>0</sub>** | **D<sub>1</sub> (k = 1)** | **D<sub>1</sub> (k = 2)** | **D<sub>1</sub> (k = 4)** |
|-------|-----------|------------|-------------------|---------------------------|---------------------------|---------------------------|
| 1     | ripple    | 35         | 146.1             | 95.0                      | 67.2                      | 47.5                      |
| 2     | ripple    | 38         | 159.4             | 128.9                     | 91.2                      | 64.5                      |
| 4     | ripple    | 45         | 188.4             | 143.1                     | 101.2                     | 71.6                      |
| 8     | ripple    | 56         | 234.5             | 181.0                     | 128.0                     | 90.5                      |
| 16    | ripple    | 79         | 330.6             | 254.0                     | 179.6                     | 127.0                     |
| 32    | ripple    | 126        | 526.1             | 384.4                     | 271.8                     | 192.2                     |
| 8     | prefix    | 45         | 188.8             | 153.9                     | 108.8                     | 76.9                      |
| 16    | prefix    | 51         | 214.2             | 185.0                     | 130.8                     | 92.5                      |
| 32    | prefix    | 57         | 239.2             | 207.9                     | 147.0                     | 103.9                     |

A design is feasible at clock f<sub>op</sub> iff γ<sub>t</sub> (D<sub>0</sub> + D<sub>1</sub>(k) γ<sub>w</sub>) ≤ 1/f<sub>op</sub>.

<img src="media/image3.png" style="width:6.97638in;height:3.06961in" />

2.  Optimal datapath width at a fixed 1 kHz operating point over the wire penalty γ<sub>w</sub> and the device-delay penalty γ<sub>t</sub> for a single tier, (a) with the register file off the die (Table IX coefficients) and (b) on the die (Table XIV coefficients, Section VI-E). The region label is the widest feasible design. Black curves are the closed-form frontiers of (12). The star marks the measured 2025 MoS<sub>2</sub> process; in (a) it lies close to the sub-boundary between ripple and prefix carry at W = 32, and the ripple label there depends on the unidentified split of (6) (Section III-C). In (b) no bit-serial region exists (Section VI-E).

At 1 kHz the widest feasible design is both the throughput optimum and the fixed-clock energy optimum among the feasible set, because CPI and the product *T* × CPI both decrease at every step in *W* across this family (Tables II and IV). The monotonicity is a property of this family, not a general one; it fails under the bandwidth-limited memory of Section IV-D, where the energy optimum moves inward to *W* = 16. Degradation of the devices or of the wires unfolds the full staircase from 32 through 16, 8, 4, 2, and 1 to the infeasible region. Along the device axis at unit wire penalty, *W* = 32 survives to *γ*<sub>t</sub> = 2.24 with prefix carry (1.10 with ripple carry), *W* = 16 to 2.51, *W* = 8 to 2.92, *W* = 4 to 3.02, and *W* = 2 to 3.47. The sole band in which bit-serial is the optimal feasible design runs from *γ*<sub>t</sub> = 3.47 to 4.15, that is, when the devices are 3.5 to 4.1× slower than the 2025 MoS<sub>2</sub> devices against the clock target. Along the wire axis at unit device delay, the staircase runs 1.23 (*W* = 32 ripple), 3.66 (*W* = 32 prefix), 4.25, 5.27, 5.67, 6.52, and 8.99 for *W* = 1. Prefix carry extends the parallel region by 3.0× along the wire axis and 2.0× along the device axis.

*Vertical partitioning.* Tiers scale *D*<sub>1</sub> alone, by the inverse square root of *k*, so every frontier shifts right by √*k* at fixed device delay (the *W* = 32 ripple wire limit moves from 1.23 to 1.74 to 2.47 for one, two, and four tiers). M3D changes no answer to the question of which width is optimal at a technology point; it moves every technology point √*k* deeper into the parallel region. This statement is as good as the 1/√*k* assumption and no better (Appendix C).

B. THE YIELD LADDER UNDER BOTH READINGS AND BOTH METRICS

The yield axis uses a Poisson defect model per transistor with no redundancy. Two metrics are evaluated. The *per-die* metric is the expected throughput per fabricated die,

$$\begin{array}{r}
E\lbrack thr\rbrack = e^{- dT}\, thr,\#(14)
\end{array}$$

appropriate when die area is set by the pad ring rather than by the core, as it is for the 6 mm × 6 mm die of \[1\]. The *per-wafer-area* metric divides (14) by *T*, appropriate when the core sets the die area and the number of dies per wafer scales as 1/*T*. The boundary between two designs sits where their metrics are equal:

$$\begin{array}{r}
d_{die}^{*} = \frac{\ln\left( {thr}_{i}/{thr}_{j} \right)}{T_{i} - T_{j}},\quad\quad d_{area}^{*} = \frac{\ln\left( {thr}_{i}/{thr}_{j} \right) - ln\left( T_{i}/T_{j} \right)}{T_{i} - T_{j}}.\#(15)
\end{array}$$

Under the delay-budget reading, thr and *T* are those of Tables II and IV; under the cascade reading they are those of Table VIII. Table X gives the resulting ladders, Fig. 3 draws them, and the following features hold.

TABLE X

THE YIELD LADDER

| **reading**  | **clock**            | **metric** | **envelope**    | **d\* (ppm/T)** | **exit yields (%)**        | **margin** |
|--------------|----------------------|------------|-----------------|-----------------|----------------------------|------------|
| delay budget | 1 kHz                | die        | 32r→16r→8r→1    | 67 / 156 / 249  | 99.993 / 99.984 / 99.975   | 3.2×       |
| delay budget | 1 kHz                | area       | 32r→16r→8r→1    | 24 / 104 / 177  | 99.998 / 99.990 / 99.982   | 4.5×       |
| delay budget | f<sub>max</sub>      | die        | 32BK→16BK→8BK→1 | 41 / 92 / 198   | 99.996 / 99.991 / 99.980   | 4.0×       |
| delay budget | f<sub>max</sub>      | area       | 16BK→8BK→1      | – / 42 / 126    | – / 99.996 / 99.987        | 6.3×       |
| cascade      | f<sub>c</sub>, 1 kHz | die        | 32BK→16BK→8BK→1 | 3.6 / 60 / 75   | 99.9996 / 99.994 / 99.9925 | 10.7×      |
| cascade      | f<sub>c</sub>, 1 kHz | area       | 16BK→1          | – / – / 33      | – / – / 99.9967            | 24×        |

Poisson boundaries d\* in defects per million transistors (ppm/T), the per-transistor yield at which the wider design stops being optimal (exit yield), and the margin by which the 2025 anchor of 800 ppm/T sits above the bit-serial boundary. Under the cascade reading the 1 kHz and compliant-clock ladders coincide because both are fixed clocks. r: ripple carry; BK: Brent–Kung.

<img src="media/image4.png" style="width:6.97638in;height:2.93008in" />

3.  The yield ladder. Expected throughput per fabricated die, (14), versus defect density for the nine designs (grey) and their upper envelope (black) under (a) the delay-budget reading at 1 kHz and (b) the cascade reading at the compliant clock. Shaded regions mark the optimal width; dotted lines are the boundaries of Table X. Red lines are three of the yield figures of Section VI-C: the per-transistor yield of 99.92% (dashed, 800 ppm/T), the 898-of-900 inverter yield (dash-dot, with its 95% band), and the effective value for 144-transistor register blocks at 71% yield (dotted, with its 95% band; a block-level value, not used in the ladders).

1\) *The boundaries are insensitive to the wire penalty.* Across *γ*<sub>w</sub> from 0.3 to 10 they move by at most 13%, and the boundary at which *W* = 32 leaves the envelope by less than 3%, so the yield axis selects the width and the wire axis does not. Propagating the compiled-benchmark mixes in place of the kernels moves every boundary by at most 3% (41/94/200 and 68/158/251) with no change of order.

2\) *The first parallel width beyond the crossover is 8 bits under the per-die metric and 8 or 16 bits under the per-area metric*; *W* = 2 and 4 never reach the envelope at zero pad cost (a pad charge of *ρ* ≥ 300 opens a narrow *W* = 4 window, Section IV-D).

3\) *The cascade reading lowers every boundary of the 1 kHz delay-budget ladders by 2.6 to 19×.* The compliant netlists widen the serial-to-parallel transistor gap from 2.6× to 3.6×, and the *W* = 32 window shrinks to 3.6 ppm/T under the per-die metric and vanishes under the per-area metric, where *W* = 16 with prefix carry is the widest design on the envelope.

C. THE 2025 ANCHOR, ITS UNCERTAINTY, AND THE CONSISTENCY CHECK

Fig. 4 collects the yield data of \[1\]. Under the Poisson model, *Y* = exp(−*dT*), the wafer-scale functional transistor yield of 99.92% gives *d* = 800 ppm/T, and the 30 × 30 inverter array, of which 898 inverters function (Supplementary Fig. 4 of \[1\]), gives 1,112 ppm/T with two transistors per inverter (exact 95% interval 135–4,018). Two block yields come from one wafer of 28 matrices of 64-bit registers, each matrix eight 8-bit shift registers of 144 transistors (Supplementary Fig. 7 of \[1\]): 71% of the 224 8-bit registers and 7% of the 64-bit registers of 1,152 transistors \[1\], that is, 2 of 28, are functional. They give 2,380 and 2,291 ppm/T, three times the per-transistor figure: the per-transistor yield understates the defect exposure of a circuit. The inverter yield, reported as 99.77% in \[1\] (898/900 = 99.78%), is not a die yield; at 800 ppm/T a 5,931-transistor die has a Poisson yield of 0.87%.

<img src="media/image7.png" style="width:3.34722in;height:2.62996in" />

4.  Yield data of \[1\] against the transistor count of the functional unit: per-transistor yield (square), 898 of 900 inverters (triangle), and the 8-bit (144-T) and 64-bit (1,152-T) registers of one wafer (circles, exact 95% intervals). Red: Poisson at 800 ppm/T. Black: negative-binomial fit to the two register sizes, *d* = 2,394 ppm/T and *α* = 30. Grey: the fit at the 95% lower bound of *α*, 1.3. Dotted lines: the fabricated die (5,931 T) and the *W* = 1 and *W* = 32 prefix cores of Table II.

*Defect clustering.* Spatial clustering \[37\], \[39\] raises chip yield at fixed device yield and raises the yield of the larger design by more than that of the smaller one, so under the negative-binomial model

$$\begin{array}{r}
Y(T) = \left( 1 + \frac{dT}{\alpha} \right)^{- \alpha}\#(16)
\end{array}$$

every boundary moves to a higher defect density while the anchor itself, *d* = *α*(*Y*<sub>T</sub><sup>−1/α</sup> − 1), stays, for *α* ≥ 1, within 0.05% of −ln *Y*<sub>T</sub>. Poisson (*α* → ∞) is therefore conservative in the direction that favors serialization. The two register sizes of Fig. 4 differ only in size, so together they fix both parameters: a binomial maximum-likelihood fit gives *d* = 2,394 ppm/T (95% interval 1,896–3,260) and *α* = 30, with a 95% lower bound of 1.3 and no upper bound; the Poisson limit is not rejected (*p* = 0.89). The data fix the yield of blocks up to about 10<sup>3</sup> transistors but not of a processor: at the size of the bit-serial core the fit gives a die yield of 10<sup>−8</sup> and the lower bound of *α* gives 1.5% (Fig. 4).

TABLE XI

CLUSTERING AND MAPPER SENSITIVITY OF THE CONSISTENCY CHECK

| **reading, metric**                | **α\* (q=1)** | **α\* (q=1.77)** | **ladder, q=1.48** | **ladder, q=1.77** | **margin, q=1.77** |
|------------------------------------|---------------|------------------|--------------------|--------------------|--------------------|
| delay budget, 1 kHz, die           | 5.0           | 7.8              | 100 / 231 / 369    | 119 / 276 / 441    | 1.8×               |
| delay budget, f<sub>max</sub>, die | 3.7           | 4.9              | 60 / 137 / 293     | 72 / 164 / 351     | 2.3×               |
| delay budget, 1 kHz, area          | 3.1           | 4.0              | 35 / 154 / 262     | 42 / 184 / 313     | 2.6×               |
| cascade, die                       | 2.1           | 2.2              | 5 / 89 / 111       | 6 / 107 / 132      | 6.1×               |
| cascade, area                      | 0.9           | 0.9              | – / – / 49         | – / – / 58         | 14×                |

α *is the smallest negative-binomial clustering parameter at which the envelope still selects W = 1 at the 800 ppm/T anchor (Poisson is α → ∞). The mapper columns scale every transistor count by 1/q, which moves every Poisson boundary to q d*; combinational-only scaling, with the 18-transistor flip-flop cost held fixed, changes the ladders by less than 2% and raises α\* at q = 1.77 to 9.2 and 5.8 in the first two rows.

*The consistency check.* The designers of \[1\] chose bit-serial execution to minimize transistor count, and the map applied to their yield data selects the same width. Under the Poisson model the per-transistor anchor of 800 ppm/T lies 3.2 to 24× and the register blocks (2,291–2,380 ppm/T) 9.2 to 72× inside the bit-serial region of every ladder of Table X, and at the fitted (*d*, *α*) the envelope selects *W* = 1 under all three per-die ladders. This is a consistency check rather than a validation, because a model that penalizes transistor count reproduces a choice made on transistor count. Its test is the clustering parameter *α*<sup>∗</sup> at which the selection at the anchor changes (Table XI): 5.0, 3.7, and 3.1 under the delay-budget reading and 2.1 and 0.9 under the cascade reading; silicon fits lie between about 1 and 5 \[38\]. The fitted *α* = 30 exceeds all five, but the register data exclude only the last (profile-likelihood *p* = 0.56, 0.43, 0.36, 0.20, and 0.02), and at the 95% lower bound of *α* the envelope selects 16 or 32 bits. A die yield from \[1\] would decide the test (Table D1).

*Mapper quality.* The measurement is the pair of legalized ABC netlists of Section IV-A, which move the direct *W* = 32-to-bit-serial boundary by 1.5× at maximum frequency and 1.4–1.7× at 1 kHz. The sensitivity is the uniform factor *q*: a mapper *q* times better at every width produces counts *T*/*q* and boundaries *q* *d*<sup>∗</sup> in (15), and Table XI evaluates it at *q* = 1.48 (the ratio at *W* = 1; the mean over the three points of Table A2 is 1.50) and 1.77 (the hand-optimized chip at *W* = 1). The uniform rows bracket the measured displacement. Within the mappers compared and the factor range *q* = 1 to 1.77 of Table XI, the consistency check holds: the anchor stays a factor of 1.8 to 14 above the bit-serial boundary. Outside that range it is untested. The numerical exit thresholds are not; they are linear in *q*, and the values quoted in the abstract are at *q* = 1 with the counts of this flow, that is, the conservative end.

*Die yield at the anchor.* Fig. 4 also shows the regime of the anchor: every design of the family has a die yield below 1% there (0.023% for the bit-serial core at 800 ppm/T), and the register statistics predict 9 × 10<sup>−6</sup> for a 5,931-transistor die, which \[1\] fabricated and operated without reporting how many dies were tested. A 10% die yield is therefore also applied as a constraint, as in Section VI-E: the width is selected among the designs with exp(−*dT*) ≥ 0.1, that is, *d* ≤ ln 10/*T* (results/yield_constrained.md). The bit-serial core meets it below 220 ppm/T (*T* = 10,474, Table II) or 149 ppm/T (*T*<sub>c</sub> = 15,500, Table VIII), every wider design only at a lower density, so above those limits no design qualifies. Below them the constraint removes the wide designs one by one, and bit-serial execution is selected at 141–220 ppm/T under the delay-budget reading per die (1 kHz and maximum frequency), 139–220 per area at 1 kHz, 126–220 per area at maximum frequency, 67–149 under the cascade reading per die, and 33–149 per area. The lower ends of the per-die windows are the feasibility limits of the next design that remains competitive, *W* = 4 with ripple carry (141 ppm/T) and *W* = 8 with prefix carry (67 ppm/T), not boundaries of Table X: inside the windows the wider designs that win in Table X fail the constraint. The constraint also brings *W* = 4 into the selection, at 130–141 ppm/T under the delay-budget reading.

D. STATIC POWER: WHERE DYNAMIC ENERGY TAKES OVER

A second scenario replaces the ratioed NMOS logic by complementary 2D CFETs, removing the static current and taking textbook CMOS transistor counts with the four-tier wire model. Dynamic energy needs the switching activity *α*<sub>sw</sub>, which is measured per design in the gate-level runs (toggles weighted by fan-out, compared at cycle boundaries, so glitches are excluded) rather than assumed:

$$\begin{array}{r}
E_{dyn} = \alpha_{sw}\, N_{pins}\, C_{eff}\, V_{dd}^{2}\, CPI.\#(17)
\end{array}$$

TABLE XII

MEASURED SWITCHING ACTIVITY AND PROJECTED CFET DYNAMIC ENERGY

| **W** | **adder** | **α<sub>sw</sub> (measured)** | **pins** | **C<sub>eff</sub> (pF)** | **E<sub>dyn</sub>/instr (nJ)** |
|-------|-----------|-------------------------------|----------|--------------------------|--------------------------------|
| 1     | ripple    | 0.0453                        | 3,316    | 1.30                     | 156.2                          |
| 2     | ripple    | 0.0571                        | 5,194    | 1.35                     | 166.5                          |
| 4     | ripple    | 0.0763                        | 5,438    | 1.36                     | 127.0                          |
| 8     | ripple    | 0.0978                        | 5,950    | 1.37                     | 104.0                          |
| 16    | ripple    | 0.1196                        | 7,018    | 1.39                     | 96.9                           |
| 32    | ripple    | 0.1028                        | 8,873    | 1.42                     | 76.8                           |
| 8     | prefix    | 0.0982                        | 6,042    | 1.37                     | 106.1                          |
| 16    | prefix    | 0.1193                        | 7,292    | 1.40                     | 100.8                          |
| 32    | prefix    | 0.0989                        | 9,486    | 1.43                     | 79.5                           |

Four-tier C<sub>eff</sub>; V<sub>dd</sub> = 4 V is retained so that it cancels from ratios, and the absolute energies are a common scale, not a prediction.

The activity rises from 0.045 at *W* = 1 to 0.12 at *W* = 16 and eases at *W* = 32: a serial datapath holds most of the netlist stable while one digit churns, and the width-invariant control dilutes the activity of the widest designs. The choice of activity dominates the projection. A uniform 0.10 \[46\] would give a parallel advantage in dynamic energy of 4.6×; the measured per-design activity gives 2.0× (156.2 against 76.8 nJ). The parallel design wins the projection in either case.

Sweeping the static power from 0.01 to 100 nW per transistor with the measured activity gives the energy-optimal width at maximum frequency in Fig. 5: *W* = 16 with prefix carry above 14–82 nW per transistor across the plotted wire penalties, which contains the measured enhancement/depletion value of 72.67 nW for *γ<sub>w</sub>* below 3.5; *W* = 32 with prefix carry across the broad middle; and *W* = 32 with ripple carry below 0.02–0.28 nW per transistor, the CFET regime in which dynamic energy favors the smaller pin count at equal CPI. No bit-serial region exists at any point of this plane across five decades of static power, under the fixed-clock and race-to-sleep assumptions of Section IV-C. The measurement of the activity moved the boundary between *W* = 16 and 32 up by close to a factor of five against the constant-activity version. This map is numerical; (17) admits no closed form across the whole plane because the two energy terms select different designs.

<img src="media/image5.png" style="width:3.34722in;height:2.61502in" />

5.  Energy-optimal width at maximum frequency over the wire penalty and the static power per transistor, with the measured per-design switching activity of Table XII, for a single tier. The dashed line marks the measured value of enhancement/depletion NMOS, 72.67 nW per transistor. No bit-serial region exists anywhere in this plane.

    E. THE REGISTER FILE ON THE DIE

Every result so far places the register file off the die, as the fabricated chip does: the 5,931-transistor RV32-WUJI holds only a register-file interface, and the storage is accessed through a memory port \[1\]. This is configuration A. A processor whose process can afford the storage on the die is configuration B, and because the register file is one of the largest and slowest blocks of any datapath, the width question has to be answered for it as well.

*Register file.* The digit-serial register file of Fig. 1 is implemented in the same RTL: 31 × 32 flip-flops (x0 is hardwired), two combinational *W*-bit read ports that select a register and a digit, and one *W*-bit digit write port with decoded enables. The library flip-flop has no enable, so every bit carries a hold multiplexer. It is synthesized alone and integrated with the core into one netlist at all nine design points through the flow of Section III-C (Table XIII) and pipelined to 17 stages by the construction of Section V; every mapping, buffering, and pipelining step is proved formally as in Sections III-C and V, with the ring of *S* − 1 phases refuted at every point. The integrated RTL executes all five kernels at every design point with results equal to the golden ISS and cycle counts equal to the core-only RTL (45 of 45), and the checksum kernel executes at gate level on each of the nine integrated, legalized netlists, to which the depth-compliant integrated netlists are proved equivalent, with the golden result and the RTL cycle count.

TABLE XIII

THE REGISTER FILE AND THE INTEGRATED CORE-PLUS-REGISTER-FILE NETLISTS (CONFIGURATION B)

| **W** | **adder** | **T<sub>RF</sub>** | **T<sub>sys</sub>** | **depth** | **delay (µs)** | **E (µJ)** | **S** | **T<sub>sys,c</sub>** |
|-------|-----------|--------------------|---------------------|-----------|----------------|------------|-------|-----------------------|
| 1     | ripple    | 62,420             | 72,869              | 38        | 290.3          | 264.8      | 3     | 104,581               |
| 2     | ripple    | 59,148             | 74,861              | 38        | 290.3          | 141.4      | 3     | 114,645               |
| 4     | ripple    | 57,562             | 73,939              | 45        | 332.3          | 75.8       | 3     | 114,079               |
| 8     | ripple    | 57,364             | 75,144              | 56        | 405.9          | 44.6       | 4     | 128,085               |
| 16    | ripple    | 56,770             | 77,468              | 78        | 566.7          | 29.2       | 5     | 155,112               |
| 32    | ripple    | 56,290             | 82,020              | 125       | 870.1          | 22.1       | 8     | 212,955               |
| 8     | prefix    | 57,364             | 75,379              | 45        | 336.8          | 44.7       | 3     | 116,402               |
| 16    | prefix    | 56,770             | 78,146              | 50        | 382.6          | 29.5       | 3     | 123,853               |
| 32    | prefix    | 56,290             | 83,540              | 56        | 426.4          | 22.5       | 4     | 139,817               |

T<sub>RF</sub> is the register file alone (its depth is 20 to 16 stages from W = 1 to 32); T<sub>sys</sub>, depth, and delay are the integrated netlist after fan-out legalization; E is the fixed-clock energy of (10) with T<sub>sys</sub>; S and T<sub>sys,c</sub> are the depth-compliant integrated netlist.

*Transistors.* The register file costs 56,290 to 62,420 transistors, 5.4 to 6.0× the bit-serial core, and it is largest at *W* = 1 because the digit multiplexer disappears as *W* grows. With it on the die the serial-to-parallel transistor ratio collapses from 2.45–2.60 to 1.13–1.15: serialization saves 11 to 13% of the die, not a factor of 2.5.

*Delay.* Both ports are in series with the core’s logic: the read port is combinational from the source-register and digit-index flip-flops into the digit ALU, and the write port takes the result digit through an inverter fan-out tree into the write multiplexer of every register bit. The write path is critical at *W* ≤ 4 and at *W* = 8 with prefix carry (38 stages and 290 µs at *W* = 1 against 34 stages and 241 µs for the core alone; +2.5%, +2.2%, and +0.8% at *W* = 2, 4, and 8 with prefix carry). Elsewhere the core’s own path remains critical, and the delay differs from Table II by at most 0.8% through the changed loading of that path. The register file therefore slows the serial end of the family and not the parallel end; all nine integrated netlists meet 1 kHz.

*Feasibility.* Table XIV gives the coefficients of (12) for the integrated netlists, with *c*<sub>w</sub> kept at the core calibration because it is a property of the process; the larger cell count raises the effective wire factor to 1.21–1.22 for every design. Fig. 2(b) is the resulting map. The serial end moves down (the *W* = 1 device-delay limit at unit wire penalty falls from 4.15 to 3.15, the wire limit from 8.99 to 5.42) and the parallel end moves little (*W* = 32 prefix: 2.24 to 2.13 and 3.66 to 3.29), so every boundary shifts in favor of width. Because the path into the register-file write port gives *W* = 1 and *W* = 2 the same critical path and *W* = 2 has half the CPI, the bit-serial region of Fig. 2(a) disappears in Fig. 2(b): with the register file on the die, bit-serial execution is never the widest feasible design.

TABLE XIV

FEASIBILITY-FRONTIER COEFFICIENTS OF (12)–(13) FOR THE INTEGRATED CORE-PLUS-REGISTER-FILE NETLISTS (CONFIGURATION B), IN MICROSECONDS, AS TABLE IX

| **W** | **adder** | **stages** | **D<sub>0</sub>** | **D<sub>1</sub> (k = 1)** | **D<sub>1</sub> (k = 2)** | **D<sub>1</sub> (k = 4)** |
|-------|-----------|------------|-------------------|---------------------------|---------------------------|---------------------------|
| 1     | ripple    | 39         | 163.6             | 154.2                     | 109.0                     | 77.1                      |
| 2     | ripple    | 39         | 163.6             | 154.2                     | 109.0                     | 77.1                      |
| 4     | ripple    | 46         | 192.6             | 169.6                     | 119.9                     | 84.8                      |
| 8     | ripple    | 56         | 234.5             | 208.7                     | 147.6                     | 104.4                     |
| 16    | ripple    | 79         | 330.6             | 288.6                     | 204.1                     | 144.3                     |
| 32    | ripple    | 126        | 525.9             | 423.6                     | 299.5                     | 211.8                     |
| 8     | prefix    | 46         | 192.8             | 175.5                     | 124.1                     | 87.7                      |
| 16    | prefix    | 51         | 214.1             | 206.1                     | 145.7                     | 103.1                     |
| 32    | prefix    | 57         | 239.2             | 230.9                     | 163.3                     | 115.5                     |

*Energy and throughput.* At a fixed 1 kHz clock the 32-bit cores use 12.0× (ripple) and 11.8× (prefix) less energy per instruction than the bit-serial core, against 5.2–5.5× in configuration A, and under iso-throughput operation without power gating the bit-serial advantage shrinks to the transistor ratio of 1.13–1.15×. Under the cascade reading the bit-serial system needs *S* = 3 instead of 2, because its critical path of 38 stages, which runs into the register-file write port, exceeds two bands of 17, so the compliant 32-bit prefix system delivers 10.1× its throughput at 7.6× less energy (16 bits: 9.6× and 8.1×), against 6.76× and 1.87× in configuration A.

*Yield.* Table XV gives the ladders of (15) with T<sub>sys</sub> and T<sub>sys,c</sub>. Every boundary moves to a higher defect density, because the transistor differences shrink while the throughput ratios do not, and a *W* = 4 window opens under the delay-budget reading. Under that reading bit-serial becomes optimal only above 1,182 ppm/T (per die, 1 kHz), so the Poisson envelope selects *W* = 4 at the 800 ppm/T anchor; under the cascade reading the anchor stays 5.2× inside the bit-serial region. These selections have to be read together with the die yield that the same model assigns to an integrated die: for the bit-serial system of 72,869 transistors it is 5 × 10<sup>−26</sup> at 800 ppm/T under Poisson statistics, and the integrated die reaches 10% only below 32 ppm/T and 50% below 9.5 ppm/T. Under a 10% die-yield constraint the integrated designs qualify only below 28 to 32 ppm/T, and the constrained selection (results/yield_constrained.md) steps from 32 bits below 28 ppm/T through 16, 8, and 4 bits to bit-serial at 31.1–31.6 ppm/T under the delay-budget reading, and from 16 bits with prefix carry below 18.6 ppm/T (32 bits below 3.2) through 8 and 4 bits to bit-serial at 20.2–22.0 ppm/T under the cascade reading. Bit-serial execution is selected only in a window of 0.5 or 1.8 ppm/T just below the density above which no integrated design qualifies. For the clustering parameters listed in Table D2 (*α* = 1 to 10) and the per-die envelope, the die yield rises and the width selected at the anchor is 8 bits or wider. The consistency check of Section VI-C is therefore a statement about configuration A, the configuration that \[1\] built.

TABLE XV

THE YIELD LADDER WITH THE REGISTER FILE ON THE DIE (CONFIGURATION B), AS TABLE X

| **reading**  | **clock**            | **metric** | **envelope**       | **d\* (ppm/T)**        | **anchor**  |
|--------------|----------------------|------------|--------------------|------------------------|-------------|
| delay budget | 1 kHz                | die        | 32r→16r→8r→4r→1    | 74 / 195 / 454 / 1,182 | W = 4       |
| delay budget | 1 kHz                | area       | 32r→16r→8r→4r→1    | 62 / 182 / 441 / 1,169 | W = 4       |
| delay budget | f<sub>max</sub>      | die        | 32BK→16BK→8BK→4r→1 | 43 / 117 / 371 / 1,056 | W = 4       |
| delay budget | f<sub>max</sub>      | area       | 32BK→16BK→8BK→4r→1 | 30 / 104 / 358 / 1,042 | W = 4       |
| cascade      | f<sub>c</sub>, 1 kHz | die        | 32BK→16BK→8BK→1    | 3 / 61 / 153           | 5.2× inside |
| cascade      | f<sub>c</sub>, 1 kHz | area       | 16BK→8BK→1         | – / 52 / 144           | 5.5× inside |

The last column is the width selected at the 800 ppm/T anchor, or the anchor's margin inside the bit-serial region.

7.  WHERE THE CROSSOVER IS, AND HOW TO USE THE MAP

    A. THE CROSSOVER

Collecting Sections IV–VI, the answer to the question of the introduction, under this model, its nine candidate designs, and the stated operating assumptions, depends on three conditions: the operating assumption, the reading of the 17-stage rule, and the placement of the register file. Table XVI collects the resulting selections.

1\) *Operating assumption.* Under fixed-clock or race-to-sleep operation with zero-wait memory, the widest feasible design among the delay-budget netlists of Table II is the throughput and energy optimum, which at the 2025 process point with a 1 kHz target is *W* = 32. Among the depth-compliant netlists of the cascade reading, *W* = 32 with prefix carry remains the throughput optimum, but *W* = 16 with prefix carry is the energy optimum (Table VIII). Under an iso-throughput requirement without power gating, the energy ordering reverses and bit-serial execution is energy-optimal (Section IV-C).

2\) *The 17-stage rule.* At the 2025 process point under fixed-clock or race-to-sleep operation, yield is the only axis that selects bit-serial execution; under an iso-throughput requirement without power gating, energy also selects it (item 1). Under the per-die metric, bit-serial execution is optimal above 249 defects per million transistors when the rule is a delay budget and above 75 when it is a cascade constraint, with 8 bits as the first parallel width (Table X). Under the cascade reading, 16 bits with prefix carry is the practical parallel optimum, and prefix carry is a prerequisite for a 32-bit datapath that beats bit-serial execution in energy. The 2025 process, at 800 ppm/T per transistor and about 2,300 ppm/T at block level, lies inside the bit-serial region under both readings, consistent with the fabricated design, at a defect density where every design has a die yield below 1% (Section VI-C). With the register file off the die and a 10% die-yield constraint, bit-serial execution is selected at 141–220 ppm/T (delay-budget reading, per die) and 67–149 ppm/T (cascade reading), where the wider designs fail the constraint (Section VI-C).

3\) *Register-file placement.* With the register file on the die, the serial-to-parallel transistor ratio falls to 1.13–1.15, bit-serial execution is never the widest feasible design (Fig. 2(b)), and under the Poisson model and a 10% die-yield constraint bit-serial execution is selected only in windows of 0.5 and 1.8 ppm/T at the edge of feasibility (Table XVI).

TABLE XVI

WIDTH SELECTED AT THE 2025 PROCESS POINT AND EXTENT OF THE BIT-SERIAL REGION, BY REGISTER-FILE PLACEMENT AND READING OF THE 17-STAGE RULE

| **RF**  | **17-stage reading** | **optimum at the 2025 point** | **bit-serial above (ppm/T)** | **at 800 ppm/T** | **bit-serial under Y ≥ 10% (ppm/T)** |
|---------|----------------------|-------------------------------|------------------------------|------------------|--------------------------------------|
| off (A) | delay budget         | *W* = 32 (r or BK)            | 249                          | *W* = 1          | 141–220                              |
| off (A) | cascade              | 32BK (thr), 16BK (*E*)        | 75                           | *W* = 1          | 67–149                               |
| on (B)  | delay budget         | *W* = 32 (r or BK)            | 1,182                        | *W* = 4          | 31.1–31.6                            |
| on (B)  | cascade              | 32BK (thr), 16BK (*E*)        | 153                          | *W* = 1          | 20.2–22.0                            |

Fixed-clock or race-to-sleep operation with zero-wait memory; Poisson per-die metric at 1 kHz (delay budget) or at the compliant clock (cascade), from Tables VIII, X, XIII, and XV. The last column is the range of defect density in which W = 1 is the optimum among the designs with a Poisson die yield of at least 10% (results/yield_constrained.md); its upper end is ln 10 divided by the bit-serial transistor count, above which no design qualifies. Under iso-throughput operation without power gating the energy ordering reverses and bit-serial execution is energy-optimal in every row. thr: throughput; *E*: energy per instruction; r: ripple carry; BK: Brent–Kung.

B. PROCEDURE FOR LOCATING ANOTHER TECHNOLOGY

Take a 2D or other device-count-limited technology with four measurements: (i) the per-transistor functional yield, which gives *d*; (ii) the stage-delay parameters relative to the 2025 MoS<sub>2</sub> values, which give *γ*<sub>t</sub> (for the intrinsic term) and, with the wire capacitance and the tier count, *γ*<sub>w</sub> and *k*; (iii) the static power per transistor *p*<sub>s</sub>; and (iv) the logic-family cascade limit, read either as a delay budget or as a hard constraint. Take a target clock and an operating assumption (fixed clock, race-to-sleep, or iso-throughput) in addition.

1\) *Feasibility.* Evaluate (12) per design with the coefficients of Table IX (register file off the die) or Table XIV (on the die). The widest feasible design at the target clock is the throughput optimum and, under fixed-clock or race-to-sleep operation with zero-wait memory, the energy optimum. This holds for the netlists of Table II; under the cascade reading, Table VIII gives the optimum (*W* = 16 with prefix carry in energy).

2\) *Yield.* Read the ladder of Table X for the applicable reading and metric. For a mapper *q* times better than this flow multiply every boundary by *q* (Table XI); for a process with known clustering use the *α* rows of Table XI; budget the pad exposure *ρ* before reading the ladder (Section IV-D); if the register file is on the die, read Table XV instead. If a minimum die yield applies, first drop every design that does not meet it at the given defect density, then select among the rest (Section VI-C, Table XVI).

3\) *Adder.* Use Brent–Kung prefix carry whenever speed, the extent of the parallel region, or compliance with a cascade rule matters; at *W* = 32 it is mandatory under a hard rule of 17 stages. The sole cases for ripple carry are fixed low-frequency operation with ample margin and the deep-CFET energy regime of Fig. 5.

4\) *Interfaces and operating assumption.* Pad energy selects no width; pad count does, through yield. A bandwidth-limited memory halves the parallel CPI advantage and moves the interior fixed-clock energy optimum to *W* = 16, but never favors bit-serial. If the application fixes the throughput and the technology cannot power-gate, invert the energy conclusion: the narrowest feasible datapath is energy-optimal.

*Reuse conditions.* The coefficients of Table IX and the ladders of Table X belong to the nine netlists mapped into 2D_NMOS_lib: 25 cells, a fan-out limit of four, an 18-transistor flip-flop, and the linear stage-delay model (3). They transfer without rerunning the flow to a process that keeps this cell set and these rules and changes only the scalar parameters: *t*<sub>0</sub> and *s* (through *γ*<sub>t</sub> and (7)), *C*<sub>pin</sub> and *c*<sub>w</sub> (through *γ*<sub>w</sub>), *k*, *p*<sub>s</sub>, and *d*. A process with a different cell set, fan-out limit, flip-flop cost, cascade limit, or a delay that is not linear in load requires remapping the RTL and recalibrating the model with the released flow; the procedure then applies to the new coefficient table. A per-stage or ring-oscillator delay should be measured in either case, because the split of (6) is otherwise unidentified.

*Worked example (the 2025 process).* *d* = 800 ppm/T (about 2,300 ppm/T at block level), *γ*<sub>t</sub> = *γ*<sub>w</sub> = 1, *k* = 1, *p*<sub>s</sub> = 72.67 nW/T, 1 kHz target. Step 1 selects *W* = 32 (ripple or prefix). Step 2 overrides it to *W* = 1 under both readings, at a defect density at which the model assigns the bit-serial die a yield below 1% (Section VI-C). Step 3 is moot at *W* = 1. The map therefore returns the fabricated design.

8.  LIMITATIONS

1\) *Relative, not absolute, quality of results.* The mapper of this flow carries a measured overhead of close to 1.5× in transistors against legalized ABC and 1.77× against the hand-optimized chip, and 1.1–2.0× in depth. The framework predicts relative architectural trends across widths within one flow, supported by a second mapper that preserves the serial-to-parallel ordering at the two widths it was applied to; it does not predict the implementation quality that careful hand design achieves at any single width. The gap to a commercial mapper with a real process design kit is unmeasured because no such kit for a 2D process was available to this study.

2\) *The register file.* Configuration A keeps it off the die, as \[1\] does, and charges only its pin and pad costs; configuration B (Section VI-E) puts one register-file microarchitecture on the die, a flip-flop array with digit-addressed read and write ports. Shift-register storage, latch-based cells, or a memory macro in a host technology would give different counts and were not synthesized; the depth-compliant integrated netlists are proved equivalent to the legalized netlists that execute at gate level. Table XIV gives the feasibility coefficients with the register file on the die; the wire model is calibrated at the core alone and extrapolated to the larger cell count.

3\) *Uniform microarchitecture.* The fixed finite-state machine forgoes width-specific optimizations on both sides; the four unshared adders inflate the parallel transistor counts, which is conservative against the parallel conclusion.

4\) *Stated assumptions in the projections.* The 1/√*k* tier rule, the CFET cell counts, the device input capacitance, and the Rent exponent are assumptions. The tier rule is inconsistent with the Donath scaling of the architecture axis (Appendix C). No model covers inter-tier vias or the thermal limits of M3D.

5\) *Yield model.* Defects per transistor with no redundancy. The register blocks of \[1\] fix the block-level density and give *α* = 30 with a 95% lower bound of 1.3, which does not decide the clustering test of Section VI-C; one reported die yield would. Mapper quality enters as the factor *q* of Table XI. The defect exposure is counted per transistor rather than per area because the dominant failure mechanisms of current 2D processes (channel-film defects, contact and threshold non-uniformity) attach to devices, and device-level yield is what \[1\] and its precursor \[4\] optimize and report. The anchor lies where the same model assigns every design a die yield below 1%; under a die-yield constraint the bit-serial selection is confined to the windows of Section VI-C.

6\) *Frequency extrapolation.* The delay model is used beyond the calibration path of 171 µs by up to 5.1× in the maximum-frequency columns; the primary conclusions stand at 1 kHz, inside the calibrated regime, and the split of (6) is swept.

7\) *Activity and clock energy.* The measured activity excludes glitches and no model covers the clock network; both omissions are conservative for Section VI-D. The low-static-power corner of Fig. 5 is the one result a glitch-aware simulator could move.

8\) *Compiled workloads are predicted, not simulated end to end.* The compiled CPIs come from the validated closed-form model (Appendix B); no compiled benchmark has run to completion at RTL or gate level, and gate-level execution stays at one program per netlist.

9\) *Scope.* Depth compliance (Section V) is compliance with the netlist-level rules of \[1\] within the model; no placement, routing, or electrical cascade simulation was performed. The map concerns the core datapath. In a complete system most transistors lie outside the core (memories, register storage, peripherals), and what this article decides is how wide that core should be, not how the system should be partitioned.

10\) *Static power per transistor.* Static power is charged per transistor, (5), at the chip average of \[1\]. In ratioed enhancement/depletion NMOS the static current flows in a gate whose pull-down network conducts, so it is set per gate and by the logic state of the gate rather than per transistor; inverters, complex gates, multiplexers, and flip-flops therefore carry weights different from those of (5). Every fixed-clock and iso-throughput energy of this article inherits the uniform weighting; the throughput, feasibility, and yield results do not depend on it. A state-weighted estimate from the output-low probabilities of the gate-level runs was not made.

9.  CONCLUSION

Within this model, its nine candidate designs, and the stated operating assumptions, bit-serial RISC-V microarchitectures on 2D semiconductors are a strategy for yield and feasibility, and, under an iso-throughput requirement without power gating, for static energy; they are not a strategy for throughput or for fixed-clock energy. At 1 kHz, evaluated with a model calibrated to the published values of the 2025 MoS<sub>2</sub> process, a 32-bit datapath achieves 13.5× the throughput and 5.2–5.5× lower energy per instruction for 2.45–2.60× the transistors. The ordering survives measured switching activity, interface costs, eighteen compiled benchmarks, an 8-bit memory bus, and the 17-stage rule read as a cascade constraint, with smaller magnitudes in the last two cases (Sections IV-D and V).

The crossover from bit-serial to parallel is therefore a defect density, given in closed form as a boundary of the model: 249 defects per million transistors when the 17-stage rule is a delay budget and 75 when it is a cascade constraint, with 8 bits as the first parallel width. The yield data of \[1\] lie inside the bit-serial region under every reading and metric, by 3.2–24× for the per-transistor yield and 9.2–72× for the register blocks, consistent with the fabricated choice, but at a defect density where the model assigns the bit-serial die a yield below 1%. The practical selection rule is therefore a die-yield constraint: at 10%, bit-serial execution is selected at 141–220 (delay-budget reading) or 67–149 (cascade reading) defects per million transistors, where every wider design fails the constraint, and no design qualifies above those ranges. The consistency check survives defect clustering down to a negative-binomial parameter of about 5 (delay-budget reading) or 2 (cascade reading); the register data of \[1\] favor weaker clustering (*α* = 30) but do not yet exclude those values.

With this register file on the die, the fixed-clock energy advantage of 32 bits rises to 12×, bit-serial is never the widest feasible design, and under the Poisson model and a 10% die-yield constraint an integrated process selects bit-serial execution only within 2 ppm/T of the density above which no design qualifies. The coefficient tables (Tables IX–XI) and the four-step procedure of Section VII-B locate other device-count-limited technologies on this map.

The source code, the synthesis flow, the formal proofs (tools/prove_flow.py), the verification suite, the register-file integration (tools/rf_system.py), the yield fit (tools/block_yield.py), and every table of this article are available at https://github.com/nhayase/M2D and from the corresponding author on request.

APPENDIX A. VALIDATION DETAILS

**V1 (calibration).** The delay pair (*t*<sub>0</sub>, *s*) is a joint calibration such that a 17-stage path at full fan-out reproduces the published 171 µs: 17 × (4.06 + 0.6 × 10) = 171.0 µs. Reference \[1\] publishes the total and no per-stage data, so the publication alone supports no independent fit of the two coefficients; the same holds for the static power per transistor and the 18-transistor flip-flop.

**V2 (cycle-exact class validation).** Two programs with *n*<sub>1</sub> and *n*<sub>2</sub> copies of one instruction give the cycle cost of its class through *c* = \[*N*<sub>cyc</sub>(*n*<sub>2</sub>) − *N*<sub>cyc</sub>(*n*<sub>1</sub>)\]/(*n*<sub>2</sub> − *n*<sub>1</sub>); the subtraction removes the fixed cost of the setup and the terminating jump. The class set covers all thirteen retirement classes of the implemented subset, including LUI, AUIPC, JAL, and JALR, at all nine design points: 117 of 117 checks match at zero tolerance. This measurement gives JALR a cost of 2*D* + 2 rather than *D* + 2 cycles; none of the five hand kernels retires a jump, so the earlier misclassification first surfaced on the compiled set (Appendix B).

**V2b (gate-level execution).** The checksum kernel runs on each of the nine mapped and legalized netlists against the same external memory and register-file environment as the RTL benches, finishing in a cycle count asserted equal to the RTL and producing the golden checksum 0x353761ae. The other four kernels and the eighteen compiled benchmarks run at RTL and on the ISS only.

**V2c (independent mapper).** The target of the ABC cross-check is the subset of its built-in gate classes with a one-to-one correspondence in 2D_NMOS_lib; each netlist is translated cell for cell, analyzed with the same transistor and delay model, legalized by the same pass, and re-verified against the emitted netlist by randomized equivalence over 8,192 patterns. That check establishes that legalization preserved what ABC emitted; the translation from ABC gate classes to library cells was verified by inspection of the cell functions and not by simulation. Legalization costs ABC between 8.7% and 13.7% of its transistors against 9.2% to 10.1% for this flow. Measured between legal netlists, the depth overhead of this flow is 1.48× at *W* = 1 and 1.69× at *W* = 32 for ripple carry, against 1.12× for the parallel-prefix design.

**V2d (coverage).** Table A1 records, for every design point, which validation stages have been executed. The released co-simulation matrix did not cover every design point; the extended matrix reaches all nine, with the suite growing from 89 to 122 tests, all passing. Configuration B (Section VI-E) adds, per design point, five kernels at RTL and the checksum kernel at gate level on the integrated netlist. The formal proofs of Sections III-C, V, and VI-E hold at all nine points of both configurations; after structural hashing, 11 to 108 outputs per core netlist and 1,000 to 1,067 per integrated netlist required the SAT solver (results/formal.md).

**V3 (chip-level gap).** The transistor gap of 1.77× against the fabricated *W* = 1 chip decomposes into 2,610 T of flip-flops, 884 T of legalization inverters, 3,249 T of multiplexer trees (immediate, program-counter, and finite-state-machine selects), and 3,731 T of other combinational logic; serial immediate decoding by hand, register-port sharing, and global restructuring in \[1\] account for the difference. ABC emits a 15-stage netlist for the same RTL that would satisfy the 17-stage rule at the price of a fan-out violation on 61 nets; legalizing it costs 283 inverters and 23 stages. The depth gap therefore lies in hand optimization and not in the mapper.

TABLE A1

VALIDATION COVERAGE BY DESIGN POINT

| **design point** | **co-sim** | **equiv.** | **kernel CPI** | **gate-level** | **compiled** | **ABC** | **pipelined** |
|------------------|------------|------------|----------------|----------------|--------------|---------|---------------|
| W = 1 ripple     | 12         | yes        | yes            | yes            | yes          | yes     | yes           |
| W = 2 ripple     | 11         | yes        | yes            | yes            | yes          | –       | yes           |
| W = 4 ripple     | 11         | yes        | yes            | yes            | yes          | –       | yes           |
| W = 8 ripple     | 11         | yes        | yes            | yes            | yes          | –       | yes           |
| W = 16 ripple    | 11         | yes        | yes            | yes            | yes          | –       | yes           |
| W = 32 ripple    | 11         | yes        | yes            | yes            | yes          | yes     | yes           |
| W = 8 prefix     | 11         | yes        | yes            | yes            | yes          | –       | yes           |
| W = 16 prefix    | 11         | yes        | yes            | yes            | yes          | –       | yes           |
| W = 32 prefix    | 11         | yes        | yes            | yes            | yes          | yes     | yes           |

co-sim: RTL co-simulation tests against the golden ISS. equiv.: formal (SAT) combinational equivalence after mapping and after legalization. kernel CPI: cycle-accurate RTL run of the five kernels asserted against the ISS, repeated with three wait states. gate-level: execution of the checksum program on the mapped netlist. compiled: 6,000-instruction prefixes of compiled Embench-IoT binaries at RTL, cycles compared against the closed-form model and data memory against the ISS. ABC: independent mapping. pipelined: the depth-compliant netlist of Section V with design rules, formal one-cycle equivalence over S periods, and gate-level execution at sub-cycle granularity.

TABLE A2

INDEPENDENT-MAPPER CROSS-CHECK WITH BOTH MAPPERS FAN-OUT-LEGALIZED

| **design**    | **mapper**            | **cells** | **T**  | **depth** | **delay (µs)** | **max FO** | **FO \> 4** |
|---------------|-----------------------|-----------|--------|-----------|----------------|------------|-------------|
| W = 1 ripple  | this flow (legalized) | 1,696     | 10,474 | 34        | 241.1          | 4          | 0           |
| W = 1 ripple  | ABC (as emitted)      | 851       | 6,490  | 15        | 120.5          | 40         | 61          |
| W = 1 ripple  | ABC (legalized)       | 1,134     | 7,056  | 23        | 175.4          | 4          | 0           |
| W = 32 ripple | this flow (legalized) | 4,526     | 25,679 | 125       | 874.6          | 4          | 0           |
| W = 32 ripple | ABC (as emitted)      | 2,821     | 15,718 | 60        | 474.2          | 84         | 214         |
| W = 32 ripple | ABC (legalized)       | 3,894     | 17,864 | 74        | 570.0          | 4          | 0           |
| W = 32 prefix | this flow (legalized) | 4,831     | 27,195 | 56        | 426.4          | 4          | 0           |
| W = 32 prefix | ABC (as emitted)      | 2,616     | 15,326 | 40        | 309.0          | 71         | 170         |
| W = 32 prefix | ABC (legalized)       | 3,536     | 17,166 | 50        | 384.5          | 4          | 0           |

ABC optimizes gate count and enforces no fan-out rule, so each of its netlists appears as emitted and after the same legalization pass; the legalized rows are the like-for-like comparison. The as-emitted delay column is an optimistic bound because the delay model saturates the load at four pins while those netlists reach fan-outs of 40 to 84.

APPENDIX B. COMPILED WORKLOADS AND THE RANGE OF INSTRUCTION MIXES

Table B1 gives the dynamic class mix of the eighteen compiled Embench-IoT benchmarks \[48\] (built with riscv-none-elf-gcc 15.2.0 at −Os, −march=rv32i −mabi=ilp32 −mstrict-align; wikisort is excluded because it needs facilities outside the implemented subset) and the CPI that the validated model assigns them at the two extreme widths. Absolute CPI on compiled code is higher than on the kernels by 1.0% at *W* = 32 and 3.6% at *W* = 1, the gap growing toward the serial end because compiled code holds procedure calls and returns that the kernels lack. At 1 kHz the compiled geometric mean gives 39.45 µJ per instruction at *W* = 1 against 6.97 (ripple) and 7.38 (prefix) at *W* = 32, a factor of 5.3 to 5.7 against 5.2 to 5.5 on the kernels.

TABLE B1

COMPILED WORKLOADS (EMBENCH-IOT, RV32I, −OS)

| **benchmark**  | **M instr** | **branch %** | **mem %** | **jump %** | **CPI W=1** | **CPI W=32** | **ratio** |
|----------------|-------------|--------------|-----------|------------|-------------|--------------|-----------|
| aha-mont64     | 14.6        | 15.2         | 1.5       | 0.7        | 54.49       | 3.56         | 15.31     |
| crc32          | 35.2        | 31.2         | 3.5       | 2.0        | 55.85       | 3.71         | 15.06     |
| depthconv      | 101.7       | 23.2         | 9.3       | 5.2        | 53.52       | 3.68         | 14.54     |
| edn            | 69.5        | 32.9         | 2.7       | 1.6        | 55.97       | 3.71         | 15.10     |
| huffbench      | 2.8         | 21.4         | 24.8      | 7.4        | 49.50       | 3.72         | 13.29     |
| matmult-int    | 25.9        | 30.5         | 7.2       | 2.4        | 54.92       | 3.72         | 14.77     |
| md5sum         | 3.4         | 13.7         | 16.2      | 3.6        | 43.93       | 3.46         | 12.71     |
| nettle-aes     | 4.8         | 3.6          | 21.3      | 1.7        | 50.73       | 3.68         | 13.78     |
| nettle-sha256  | 5.1         | 3.1          | 12.3      | 0.4        | 48.88       | 3.52         | 13.87     |
| nsichneu       | 2.0         | 38.4         | 61.2      | 0.1        | 66.45       | 4.61         | 14.42     |
| picojpeg       | 4.5         | 10.4         | 20.9      | 7.1        | 49.81       | 3.67         | 13.59     |
| qrduino        | 5.6         | 18.7         | 19.0      | 5.6        | 50.45       | 3.69         | 13.66     |
| sglib-combined | 3.2         | 21.8         | 35.8      | 9.1        | 52.00       | 3.91         | 13.30     |
| slre           | 3.1         | 20.1         | 31.3      | 10.5       | 48.34       | 3.75         | 12.89     |
| statemate      | 3.7         | 10.3         | 47.0      | 2.3        | 44.22       | 3.77         | 11.71     |
| tarfind        | 12.5        | 33.8         | 5.5       | 2.4        | 55.23       | 3.71         | 14.88     |
| ud             | 7.4         | 21.8         | 18.0      | 7.0        | 50.38       | 3.68         | 13.68     |
| xgboost        | 3.2         | 13.0         | 29.0      | 2.5        | 52.17       | 3.81         | 13.71     |
| geometric mean | –           | –            | –         | –          | 51.82       | 3.74         | 13.87     |

Dynamic instruction counts are for complete, self-verified executions on the golden ISS; mem % is loads plus stores and jump % is JAL plus JALR. CPI is the closed-form model (8) on the measured mix.

*RTL spot-check of the model on compiled code.* The first 6,000 retired instructions of four binaries (slre, ud, sglib-combined, qrduino) ran on the RTL core at all nine design points. In every one of the 36 runs the measured cycle count equals the closed-form prediction at zero tolerance and the complete data memory matches the golden ISS. Two of the four prefixes retire JALR (137 and 111 of 6,000); on those, a model that classified JALR as a one-stage jump would be short by 0.73 and 0.59 CPI at *W* = 1. The model is not an approximation fitted to the hand kernels; it is exact on compiled code.

*Exact envelope.* Because the per-class costs of (1) are fixed integers and CPI is linear in the class-frequency vector, CPI(1)/CPI(32) is a ratio of linear forms on the probability simplex and attains its extrema at vertices (single-class programs):

$$\begin{array}{r}
\min_{c}\frac{c_{c}(1)}{c_{c}(32)} \leq \frac{CPI(1)}{CPI(32)} \leq \max_{c}\frac{c_{c}(1)}{c_{c}(32)}.\#(B1)
\end{array}$$

The envelope runs from 8.75 (stores alone, 35 against 4 cycles) to 24.25 (right shifts by 31 alone, 97 against 4). With the transistor ratio of 2.45 to 2.60, the fixed-clock energy per instruction favors the parallel design by 3.4× (prefix carry, store vertex) to 9.9× (ripple carry, right-shift vertex) for every conceivable workload, and throughput by 8.8 to 24.3×.

APPENDIX C. WIRE MODEL CAVEATS AND RENT SENSITIVITY

Three caveats attach to (9). *Magnitude.* The cell count spans a factor of 2.85 across the family, so the architecture dependence of the effective wire factor is a systematic penalty of small size, +10.6% on the widest design; the map boundaries carry the conclusions and this penalty does not. *Tail.* Applying an average length to the critical path is an approximation; any constant tail factor multiplies *c*<sub>w</sub>, and the calibration and the *γ*<sub>w</sub> axis absorb it at zero residual, so no boundary or ratio depends on it. *Tier rule.* The architecture axis uses Donath scaling while the tier axis uses a geometric 1/√*k*; a tier rule consistent with Donath would give *k*<sup>p−1/2</sup> = 0.87 at *k* = 4 instead of 0.50. The geometric rule is kept because it is the 3D-integration convention \[36\], and Section VI-A reports its effect in closed form as a factor √*k* so that a reader may substitute another rule.

Rederiving the wire model for Rent exponents 0.5, 0.6, and 0.75 crossed with prefactors 0.5, 0.9, and 2.0, with recalibration to the measured 2.5 pF per pin at each pair, removes the prefactor from every result. The exponent moves three quantities: the effective wire factor of the widest design from 1.000 to 1.287, the boundary at which *W* = 32 leaves the envelope from 40.5 (p = 0.5) to 34.7 ppm/T (p = 0.75), +5% to −10% about 38.4 at p = 0.6, and the *W* = 32 ripple wire limit from 1.36 to 1.06, +11% to −14% about 1.23. No ordering changes at any point of the swept box.

TABLE C1

EFFECTIVE WIRE FACTOR VERSUS WIDTH AND TIER COUNT

| **W** | **adder** | **N cells** | **flat (k = 1)** | **2-tier** | **4-tier** |
|-------|-----------|-------------|------------------|------------|------------|
| 1     | ripple    | 1,696       | 1.000            | 0.719      | 0.520      |
| 2     | ripple    | 2,534       | 1.039            | 0.747      | 0.540      |
| 4     | ripple    | 2,664       | 1.044            | 0.750      | 0.542      |
| 8     | ripple    | 2,937       | 1.054            | 0.757      | 0.547      |
| 16    | ripple    | 3,510       | 1.072            | 0.770      | 0.556      |
| 32    | ripple    | 4,526       | 1.099            | 0.789      | 0.570      |
| 8     | prefix    | 2,978       | 1.056            | 0.758      | 0.548      |
| 16    | prefix    | 3,646       | 1.076            | 0.773      | 0.558      |
| 32    | prefix    | 4,831       | 1.106            | 0.794      | 0.573      |

λ<sub>eff</sub> = C<sub>eff</sub>/C<sub>pin</sub> is a derived quantity, not a free constant.

APPENDIX D. CLUSTERING: WIDTH SELECTED AT THE ANCHOR

Table D1 gives the width selected by the per-die envelope at the 800 ppm/T anchor under the negative-binomial model (16) as the clustering parameter is swept, together with the die yield that the same anchor implies for the fabricated 5,931-transistor chip. The anchor itself moves by less than 0.05% across the sweep. The last column is the independent handle on *α*: a reported die yield would select a row.

TABLE D1

WIDTH SELECTED AT THE ANCHOR VERSUS CLUSTERING (PER-DIE METRIC)

| **α** | **regime** | **delay budget (Table II), f<sub>max</sub>** | **delay budget (Table II), 1 kHz** | **cascade (Table VIII)**           | **Y of a 5,931-T die** |
|-------|------------|----------------------------------------------|------------------------------------|------------------------------------|------------------------|
| ∞     | Poisson    | W = 1                                        | W = 1                              | W = 1                              | 0.87 %                 |
| 10    | weak       | W = 1                                        | W = 1                              | W = 1                              | 2.06 %                 |
| 5     | weak       | W = 1                                        | W = 8 ripple                       | W = 1                              | 3.55 %                 |
| 3     | moderate   | W = 8 prefix                                 | W = 16 ripple                      | W = 1                              | 5.81 %                 |
| 2     | moderate   | W = 16 prefix                                | W = 16 ripple                      | W = 16 prefix (break-even α = 2.1) | 8.79 %                 |
| 1     | strong     | W = 32 prefix                                | W = 32 ripple                      | W = 16 prefix                      | 17.40 %                |

The consistency check is the statement that the selected width is W = 1; the three selection columns differ in the netlists and clock used.

TABLE D2

CONFIGURATION B UNDER DEFECT CLUSTERING: WIDTH SELECTED BY THE PER-DIE ENVELOPE AT THE 800 PPM/T ANCHOR UNDER THE NEGATIVE-BINOMIAL MODEL (16), AND THE DIE YIELD THE SAME MODEL ASSIGNS TO THE INTEGRATED BIT-SERIAL SYSTEM OF 72,869 TRANSISTORS

| **α** | **delay budget, 1 kHz** | **delay budget, f<sub>max</sub>** | **cascade**   | **Y of the 72,869-T die** |
|-------|-------------------------|-----------------------------------|---------------|---------------------------|
| ∞     | W = 4 ripple            | W = 4 ripple                      | W = 1         | 5 × 10<sup>−26</sup>      |
| 10    | W = 16 ripple           | W = 16 prefix                     | W = 8 prefix  | 5 × 10<sup>−9</sup>       |
| 5     | W = 32 ripple           | W = 16 prefix                     | W = 16 prefix | 3 × 10<sup>−6</sup>       |
| 3     | W = 32 ripple           | W = 32 prefix                     | W = 16 prefix | 0.012 %                   |
| 2     | W = 32 ripple           | W = 32 prefix                     | W = 16 prefix | 0.11 %                    |
| 1     | W = 32 ripple           | W = 32 prefix                     | W = 16 prefix | 1.7 %                     |

Poisson is α → ∞; the cascade-reading break-even is α\* = 21.

ACKNOWLEDGMENT

The author thanks the maintainers of the Minerva, SERV, Amaranth, yosys, ABC, and Embench projects, on which this work builds.

REFERENCES

1.  M. Ao, X. Zhou, X. Kong, S. Gou, S. Chen, X. Dong, Y. Zhu, Q. Sun, Z. Zhang, J. Zhang, Q. Zhang, Y. Hu, C. Sheng, K. Wang, S. Wang, J. Wan, J. Han, W. Bao, and P. Zhou, "A RISC-V 32-bit microprocessor based on two-dimensional semiconductors," *Nature*, vol. 640, pp. 654–661, 2025, doi: 10.1038/s41586-025-08759-9.

2.  S. Wachter, D. K. Polyushkin, O. Bethge, and T. Mueller, "A microprocessor based on a two-dimensional semiconductor," *Nat. Commun.*, vol. 8, art. no. 14948, 2017.

3.  S. Ghosh, Y. Zheng, M. Rafiq, H. Ravichandran, Y. Sun, C. Chen, M. Goswami, N. U. Sakib, M. U. K. Sadaf, A. Pannone, S. Ray, J. M. Redwing, Y. Yang, S. Sahay, and S. Das, "A complementary two-dimensional material-based one instruction set computer," *Nature*, vol. 642, pp. 327–335, 2025, doi: 10.1038/s41586-025-08963-7.

4.  X. Chen et al., "Wafer-scale functional circuits based on two dimensional semiconductors with fabrication optimized by machine learning," *Nat. Commun.*, vol. 12, art. no. 5953, 2021.

5.  D. Fan et al., "Two-dimensional semiconductor integrated circuits operating at gigahertz frequencies," *Nat. Electron.*, vol. 6, pp. 879–887, 2023.

6.  S. Das et al., "Transistors based on two-dimensional materials for future integrated circuits," *Nat. Electron.*, vol. 4, pp. 786–799, 2021.

7.  Y. Liu et al., "Promises and prospects of two-dimensional transistors," *Nature*, vol. 591, pp. 43–53, 2021.

8.  H. Wang et al., "Integrated circuits based on bilayer MoS<sub>2</sub> transistors," *Nano Lett.*, vol. 12, pp. 4674–4680, 2012.

9.  L. Yu et al., "Design, modeling, and fabrication of chemical vapor deposition grown MoS<sub>2</sub> circuits with E-mode FETs for large-area electronics," *Nano Lett.*, vol. 16, pp. 6349–6356, 2016.

10. W. Li et al., "Approaching the quantum limit in two-dimensional semiconductor contacts," *Nature*, vol. 613, no. 7943, pp. 274–279, 2023, doi: 10.1038/s41586-022-05431-4.

11. G. Migliato Marega et al., "Logic-in-memory based on an atomically thin semiconductor," *Nature*, vol. 587, pp. 72–77, 2020.

12. P.-C. Shen et al., "Ultralow contact resistance between semimetal and monolayer semiconductors," *Nature*, vol. 593, no. 7858, pp. 211–217, 2021, doi: 10.1038/s41586-021-03472-9.

13. M. M. Shulaker et al., "Three-dimensional integration of nanotechnologies for computing and data storage on a single chip," *Nature*, vol. 547, pp. 74–78, 2017.

14. J.-H. Kang et al., "Monolithic 3D integration of 2D materials-based electronics towards ultimate edge computing solutions," *Nat. Mater.*, vol. 22, pp. 1470–1477, 2023.

15. S. Ghosh et al., "Monolithic and heterogeneous three-dimensional integration of two-dimensional materials with high-density vias," *Nat. Electron.*, vol. 7, no. 10, pp. 892–903, 2024.

16. A. Pal et al., "Three-dimensional transistors with two-dimensional semiconductors for future CMOS scaling," *Nat. Electron.*, vol. 7, pp. 1147–1157, 2024.

17. D. E. Nikonov and I. A. Young, "Overview of beyond-CMOS devices and a uniform methodology for their benchmarking," *Proc. IEEE*, vol. 101, no. 12, pp. 2498–2533, Dec. 2013, doi: 10.1109/JPROC.2013.2252317.

18. M. Nguyen et al., *Minerva: A 32-bit RISC-V soft processor*. \[Online\]. Available: https://github.com/minerva-cpu/minerva (accessed Aug. 12, 2026).

19. O. Kindgren et al., *SERV: The SErial RISC-V CPU*. \[Online\]. Available: https://github.com/olofk/serv (accessed Aug. 12, 2026).

20. C. Mead and L. Conway, *Introduction to VLSI Systems*. Reading, MA, USA: Addison-Wesley, 1980.

21. R. I. Hartley and K. K. Parhi, *Digit-Serial Computation*. Norwell, MA, USA: Kluwer Academic, 1995.

22. A. Waterman and K. Asanović, Eds., *The RISC-V Instruction Set Manual, Volume I: Unprivileged ISA*, RISC-V Foundation, 2019.

23. A. Raisiardali, K. Iordanou, J. Kufel, K. Gudimetla, K. Myny, and E. Ozer, "Flexing RISC-V instruction subset processors to extreme edge," arXiv:2505.04567, 2025.

24. O. Kindgren, *QERV*. \[Online\]. Available: https://github.com/olofk/qerv (accessed Oct. 5, 2026).

25. M. Kissich and M. Baunach, "FazyRV: Closing the gap between 32-bit and bit-serial RISC-V cores with a scalable implementation," in *Proc. 21st ACM Int. Conf. Computing Frontiers (CF)*, 2024, pp. 240–248, doi: 10.1145/3649153.3649195.

26. S. Prakash et al., "Lifetime-aware design for item-level intelligence at the extreme edge," in *Proc. 31st ACM Int. Conf. Architectural Support for Programming Languages and Operating Systems (ASPLOS)*, 2026, doi: 10.1145/3779212.3790182.

27. C. Ewert et al., "SAILOR: A scalable and energy-efficient ultra-lightweight RISC-V for IoT security," arXiv:2602.24166, 2026.

28. R. P. Brent and H. T. Kung, "A regular layout for parallel adders," *IEEE Trans. Comput.*, vol. C-31, no. 3, pp. 260–264, 1982.

29. P. M. Kogge and H. S. Stone, "A parallel algorithm for the efficient solution of a general class of recurrence equations," *IEEE Trans. Comput.*, vol. C-22, no. 8, pp. 786–793, 1973.

30. J. Sklansky, "Conditional-sum addition logic," *IRE Trans. Electron. Comput.*, vol. EC-9, pp. 226–231, 1960.

31. R. E. Ladner and M. J. Fischer, "Parallel prefix computation," *J. ACM*, vol. 27, no. 4, pp. 831–838, 1980.

32. W. E. Donath, "Placement and average interconnection lengths of computer logic," *IEEE Trans. Circuits Syst.*, vol. 26, no. 4, pp. 272–277, 1979.

33. B. S. Landman and R. L. Russo, "On a pin versus block relationship for partitions of logic graphs," *IEEE Trans. Comput.*, vol. C-20, no. 12, pp. 1469–1479, 1971.

34. P. Christie and D. Stroobandt, "The interpretation and application of Rent's rule," *IEEE Trans. Very Large Scale Integr. (VLSI) Syst.*, vol. 8, no. 6, pp. 639–648, 2000.

35. M. M. Sabry Aly et al., "Energy-efficient abundant-data computing: The N3XT 1,000x," *Computer*, vol. 48, no. 12, pp. 24–33, 2015.

36. A. Rahman and R. Reif, "System-level performance evaluation of three-dimensional integrated circuits," *IEEE Trans. Very Large Scale Integr. (VLSI) Syst.*, vol. 8, no. 6, pp. 671–678, Dec. 2000, doi: 10.1109/92.902261.

37. C. H. Stapper, F. M. Armstrong, and K. Saji, "Integrated circuit yield statistics," *Proc. IEEE*, vol. 71, no. 4, pp. 453–470, 1983.

38. J. A. Cunningham, "The use and evaluation of yield models in integrated circuit manufacturing," *IEEE Trans. Semicond. Manuf.*, vol. 3, no. 2, pp. 60–71, May 1990, doi: 10.1109/66.53188.

39. I. Koren and Z. Koren, "Defect tolerance in VLSI circuits: Techniques and yield analysis," *Proc. IEEE*, vol. 86, no. 9, pp. 1819–1838, 1998.

40. N. Bleier, C. Lee, F. Rodriguez, A. Sou, S. White, and R. Kumar, "FlexiCores: Low footprint, high yield, field reprogrammable flexible microprocessors," in *Proc. 49th Annu. Int. Symp. Computer Architecture (ISCA)*, 2022, pp. 831–846.

41. C. Wolf, *Yosys Open SYnthesis Suite*. \[Online\]. Available: https://yosyshq.net/yosys/ (accessed Aug. 12, 2026).

42. K. Keutzer, "DAGON: Technology binding and local optimization by DAG matching," in *Proc. 24th ACM/IEEE Design Automation Conf. (DAC)*, 1987, pp. 341–347, doi: 10.1145/37888.37940.

43. A. Mishchenko, S. Chatterjee, and R. K. Brayton, "DAG-aware AIG rewriting: A fresh look at combinational logic synthesis," in *Proc. 43rd Design Automation Conf. (DAC)*, San Francisco, CA, USA, 2006, pp. 532–535, doi: 10.1145/1146909.1147048.

44. A. Mishchenko, S. Chatterjee, R. Brayton, and N. Eén, "Improvements to combinational equivalence checking," in *Proc. IEEE/ACM Int. Conf. Computer-Aided Design (ICCAD)*, 2006, pp. 836–843.

45. C. E. Leiserson and J. B. Saxe, "Retiming synchronous circuitry," *Algorithmica*, vol. 6, no. 1, pp. 5–35, 1991, doi: 10.1007/BF01759032.

46. F. N. Najm, "A survey of power estimation techniques in VLSI circuits," *IEEE Trans. Very Large Scale Integr. (VLSI) Syst.*, vol. 2, no. 4, pp. 446–455, Dec. 1994, doi: 10.1109/92.335013.

47. *Amaranth HDL: A modern hardware definition language and toolchain based on Python* (version 0.5.9). \[Online\]. Available: https://github.com/amaranth-lang/amaranth (accessed Aug. 12, 2026).

48. Embench, *Embench IoT Benchmark Suite*. \[Online\]. Available: https://embench.org (accessed Aug. 12, 2026).

49. J. L. Hennessy and D. A. Patterson, *Computer Architecture: A Quantitative Approach*, 6th ed. Cambridge, MA, USA: Morgan Kaufmann, 2019.

<img src="media/image6.jpeg" style="width:1.00853in;height:1.04331in" />Naoki Hayase received the B.E. degree in electrical engineering from Tokyo University of Science, Japan in 2018, and the M.E. degree in electrical engineering and information systems from the University of Tokyo, Japan in 2020. He has been an Assistant Professor at University of Hyogo since 2025. His research interests include thin solid films, interfacial engineering, X-ray optics, and semiconductor devices.
