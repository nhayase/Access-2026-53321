#!/usr/bin/env python3
"""Numbers added in the v14 revision of the IEEE Access manuscript.

Reads results/study.csv and results/depth_compliant.json of m2d_v6_4 and
prints every new table:

  1. Poisson yield ladders under the two readings of the 17-stage rule
     (delay budget -> Table II netlists; cascade constraint -> Table IX
     netlists), each for a fixed clock and for f_max, each under the
     per-die metric E[thr] = Y thr and the per-wafer-area metric Y thr / T.
  2. Exit yields and the margin of the 800 ppm anchor for each ladder.
  3. Anchor uncertainty: exact (Clopper-Pearson) interval for 898/900
     inverters, converted to a per-transistor defect density.
  4. Iso-throughput energy comparison.
  5. Negative-binomial break-even clustering alpha* for each ladder.
  6. Mapper-quality scaling q for the cascade ladder.

Usage: python3 revision_numbers.py <path to m2d_v6_4>
"""
import csv, json, math, sys
from scipy.stats import beta
from scipy.optimize import brentq

root = sys.argv[1] if len(sys.argv) > 1 else "."
PS = 72.67e-9          # W per transistor
ANCHOR = -math.log(0.9992)   # per transistor, Poisson reading of 99.92 %

rows = list(csv.DictReader(open(f"{root}/results/study.csv")))
comp = json.load(open(f"{root}/results/depth_compliant.json"))

def design(r):
    return f"W={r['width']} {r['adder']}"

# ---------------------------------------------------------------- designs
# delay-budget reading: Table II netlists
A = {}
for r in rows:
    T = int(r["transistors"]); cpi = float(r["cpi_geomean"])
    fmax = float(r["fmax_hz"])
    A[design(r)] = dict(T=T, cpi=cpi, thr_1k=1000.0 / cpi, thr_fmax=fmax / cpi)
# cascade reading: Table IX netlists (compliant clock 5,847 Hz)
C = {}
for r in comp:
    key = f"W={r['width']} {r['adder']}"
    C[key] = dict(T=r["T_c"], cpi=r["cpi_c"], thr_1k=1000.0 / r["cpi_c"],
                  thr_fmax=r["f_c_hz"] / r["cpi_c"])

# ---------------------------------------------------------------- envelope
def log_metric(des, d, thr_key, per_area, alpha=None):
    T = des["T"]
    if alpha is None:
        ly = -d * T
    else:
        ly = -alpha * math.log1p(d * T / alpha)
    v = ly + math.log(des[thr_key])
    if per_area:
        v -= math.log(T)
    return v

def envelope(designs, thr_key, per_area, alpha=None, d_lo=1e-8, d_hi=5e-3, n=20000):
    """Upper envelope over d: returns list of (name, d_from)."""
    seq = []
    for i in range(n + 1):
        d = d_lo * (d_hi / d_lo) ** (i / n)
        best = max(designs, key=lambda k: log_metric(designs[k], d, thr_key, per_area, alpha))
        if not seq or seq[-1][0] != best:
            seq.append((best, d))
    # refine each switch by root finding
    out = [(seq[0][0], 0.0)]
    for j in range(1, len(seq)):
        a, b = designs[seq[j - 1][0]], designs[seq[j][0]]
        f = lambda d: log_metric(a, d, thr_key, per_area, alpha) - log_metric(b, d, thr_key, per_area, alpha)
        dstar = brentq(f, seq[j][1] / 1.01, seq[j][1] * 1.01) if f(seq[j][1] / 1.01) * f(seq[j][1] * 1.01) < 0 else seq[j][1]
        out.append((seq[j][0], dstar))
    return out

def show(title, designs, thr_key, per_area, alpha=None):
    env = envelope(designs, thr_key, per_area, alpha)
    print(f"\n## {title}")
    print("| optimal design | from d (ppm/T) | exit yield of the wider design |")
    print("|:--|--:|--:|")
    for i, (name, d) in enumerate(env):
        if i == 0:
            print(f"| {name} | 0 | -- |")
        else:
            print(f"| {name} | {d*1e6:.1f} | {math.exp(-d)*100:.4f} % |")
    last = env[-1][1]
    if last > 0:
        print(f"margin of the 800 ppm anchor above the last boundary: x{ANCHOR/last:.2f}")
    return env

print("# 1-2. Poisson ladders")
ladders = {}
for reading, designs in (("delay budget (Table II)", A), ("cascade constraint (Table IX)", C)):
    for clk, key in (("fixed clock", "thr_1k"), ("f_max / f_c", "thr_fmax")):
        for metric, pa in (("per die", False), ("per wafer area", True)):
            ladders[(reading, clk, metric)] = show(f"{reading}, {clk}, {metric}", designs, key, pa)

# ---------------------------------------------------------------- anchor CI
print("\n# 3. Anchor uncertainty")
k, n = 2, 900
lo, hi = beta.ppf(0.025, k, n - k + 1), beta.ppf(0.975, k + 1, n - k)
print(f"inverter failures {k}/{n}: 95 % CI on the failure fraction = [{lo:.2e}, {hi:.2e}]")
print(f"per-transistor d (2 T per E/D inverter, d = -ln(1-p)/2): point {(-math.log(1-k/n))/2*1e6:.0f} ppm, "
      f"CI [{-math.log(1-lo)/2*1e6:.0f}, {-math.log(1-hi)/2*1e6:.0f}] ppm")
print(f"transistor anchor 99.92 %: {ANCHOR*1e6:.0f} ppm (sample size not reported in [1])")

# ---------------------------------------------------------------- iso-throughput
print("\n# 4. Energy per instruction under three operating assumptions (delay-budget reading, static power only)")
ser = A["W=1 ripple"]
for name in ("W=32 ripple", "W=32 prefix", "W=16 prefix"):
    par = A[name]
    e_fixed_ser = PS * ser["T"] * ser["cpi"] / 1000
    e_fixed_par = PS * par["T"] * par["cpi"] / 1000
    # iso-throughput: parallel clock f_par = 1000 * cpi_par / cpi_ser -> time/instr equal
    e_iso_par = PS * par["T"] * ser["cpi"] / 1000
    # race-to-sleep: parallel runs at 1 kHz, gated when idle -> same as fixed clock
    print(f"{name}: fixed 1 kHz  serial {e_fixed_ser*1e6:.2f} uJ vs parallel {e_fixed_par*1e6:.2f} uJ "
          f"(x{e_fixed_ser/e_fixed_par:.2f} for parallel); iso-throughput ({1000*par['cpi']/ser['cpi']:.0f} Hz parallel clock): "
          f"parallel {e_iso_par*1e6:.2f} uJ (x{e_iso_par/e_fixed_ser:.2f} for serial); race-to-sleep = fixed-clock figure")
print("cascade reading, compliant clock:")
serc = C["W=1 ripple"]
for name in ("W=32 prefix", "W=16 prefix"):
    par = C[name]
    fc = 5847.3
    e_s = PS * serc["T"] * serc["cpi"] / fc; e_p = PS * par["T"] * par["cpi"] / fc
    e_iso = PS * par["T"] * serc["cpi"] / fc
    print(f"{name}: fixed clock serial {e_s*1e6:.2f} vs parallel {e_p*1e6:.2f} uJ (x{e_s/e_p:.2f}); "
          f"iso-throughput parallel {e_iso*1e6:.2f} uJ (x{e_iso/e_s:.2f} for serial)")

# ---------------------------------------------------------------- clustering break-even
print("\n# 5. Negative-binomial break-even alpha* (smallest alpha at which the envelope still selects W=1 at the anchor)")
def selected(designs, thr_key, per_area, alpha):
    d = ANCHOR if alpha is None else alpha * (0.9992 ** (-1 / alpha) - 1)
    return max(designs, key=lambda k: log_metric(designs[k], d, thr_key, per_area, alpha))
for reading, designs in (("delay budget", A), ("cascade", C)):
    for clk, key in (("fixed clock", "thr_1k"), ("f_max / f_c", "thr_fmax")):
        for metric, pa in (("per die", False), ("per area", True)):
            if selected(designs, key, pa, None) != "W=1 ripple":
                print(f"{reading}, {clk}, {metric}: Poisson does not select W=1"); continue
            a_hi, a_lo = 1e5, 0.3
            if selected(designs, key, pa, a_lo) == "W=1 ripple":
                print(f"{reading}, {clk}, {metric}: W=1 selected for every alpha >= {a_lo}"); continue
            f = lambda a: 1.0 if selected(designs, key, pa, a) == "W=1 ripple" else -1.0
            lo_, hi_ = a_lo, 200.0
            for _ in range(60):
                mid = math.sqrt(lo_ * hi_)
                if f(mid) > 0: hi_ = mid
                else: lo_ = mid
            print(f"{reading}, {clk}, {metric}: alpha* = {hi_:.1f}")

# ---------------------------------------------------------------- mapper quality
print("\n# 6. Mapper-quality scaling of the cascade ladder (uniform T' = T/q; d*(q) = q d*(1))")
for q in (1.0, 1.48, 1.77, 2.0):
    for clk, key in (("fixed clock", "thr_1k"), ("f_c", "thr_fmax")):
        env = ladders[("cascade constraint (Table IX)", "fixed clock" if clk == "fixed clock" else "f_max / f_c", "per die")]
        lad = " / ".join(f"{d*1e6*q:.0f}" for _, d in env[1:])
        print(f"q={q:.2f} {clk}: {lad} ppm; margin x{ANCHOR/(env[-1][1]*q):.2f}")

print("\n# 7. alpha* with mapper quality q (uniform T' = T/q)")
def selected_q(designs, thr_key, per_area, alpha, q):
    ds = {k: dict(v, T=v["T"] / q) for k, v in designs.items()}
    return selected(ds, thr_key, per_area, alpha)
for q in (1.48, 1.77):
    for reading, designs in (("delay budget", A), ("cascade", C)):
        for clk, key in (("fixed clock", "thr_1k"), ("f_max / f_c", "thr_fmax")):
            for metric, pa in (("per die", False), ("per area", True)):
                if selected_q(designs, key, pa, None, q) != "W=1 ripple":
                    print(f"q={q} {reading}, {clk}, {metric}: Poisson does not select W=1"); continue
                if selected_q(designs, key, pa, 0.3, q) == "W=1 ripple":
                    print(f"q={q} {reading}, {clk}, {metric}: W=1 for all alpha >= 0.3"); continue
                lo_, hi_ = 0.3, 200.0
                for _ in range(60):
                    mid = math.sqrt(lo_ * hi_)
                    if selected_q(designs, key, pa, mid, q) == "W=1 ripple": hi_ = mid
                    else: lo_ = mid
                print(f"q={q} {reading}, {clk}, {metric}: alpha* = {hi_:.1f}")
