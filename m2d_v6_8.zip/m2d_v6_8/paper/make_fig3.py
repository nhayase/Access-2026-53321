import csv, json, math, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = sys.argv[1]
rows = list(csv.DictReader(open(f"{root}/results/study.csv")))
comp = json.load(open(f"{root}/results/depth_compliant.json"))

A = {f"W={r['width']} {r['adder']}": (int(r["transistors"]), 1000.0 / float(r["cpi_geomean"])) for r in rows}
C = {f"W={r['width']} {r['adder']}": (r["T_c"], r["f_c_hz"] / r["cpi_c"]) for r in comp}

ladA = [("W=32 ripple", 0), ("W=16 ripple", 67.3), ("W=8 ripple", 156.0), ("W=1 ripple", 249.2)]
ladC = [("W=32 prefix", 0), ("W=16 prefix", 3.6), ("W=8 prefix", 60.4), ("W=1 ripple", 74.7)]

d = np.logspace(0, math.log10(5000), 600)  # ppm
fig, axes = plt.subplots(1, 2, figsize=(10, 4.2), sharey=False)
for ax, designs, lad, title in ((axes[0], A, ladA, "(a) delay-budget reading, Table II netlists, 1 kHz"),
                                (axes[1], C, ladC, "(b) cascade reading, Table IX netlists, 5,847 Hz")):
    for name, (T, thr) in designs.items():
        y = np.exp(-d * 1e-6 * T) * thr
        ax.plot(d, y, color="0.7", lw=0.8)
    # envelope
    env = np.max([np.exp(-d * 1e-6 * T) * thr for T, thr in designs.values()], axis=0)
    ax.plot(d, env, color="k", lw=2.0, label="envelope")
    cols = {"32": "#2c5f8a", "16": "#1f5c2e", "8": "#4c9a4c", "1": "#b89a86"}
    edges = [x for _, x in lad[1:]] + [5000]
    starts = [1] + edges[:-1]
    for (name, _), s, e in zip(lad, starts, edges):
        w = name.split()[0][2:]
        ax.axvspan(s, e, color=cols[w], alpha=0.18, lw=0)
        xm = math.sqrt(max(s, 1) * e)
        ax.text(xm, 1.5, name.replace("ripple", "r").replace("prefix", "BK"), ha="center", va="bottom", fontsize=8, rotation=90)
    for _, x in lad[1:]:
        ax.axvline(x, color="k", lw=0.6, ls=":")
    ax.axvspan(135, 4018, color="red", alpha=0.07, lw=0)
    ax.axvspan(1830, 3040, color="red", alpha=0.12, lw=0)
    ax.axvline(800, color="red", lw=1.3, ls="--")
    ax.axvline(1112, color="red", lw=0.8, ls="-.")
    ax.axvline(2378, color="red", lw=0.8, ls=":")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(1, 5000); ax.set_ylim(1, 1000)
    ax.set_xlabel("defect density $d$ (defects per $10^6$ transistors)")
    ax.set_title(title, fontsize=9.5)
    ax.grid(True, which="both", lw=0.3, alpha=0.4)
axes[0].set_ylabel("expected throughput per fabricated die (instr/s)")
axes[1].text(800, 700, "800 ppm (99.92 % per T) ", color="red", fontsize=7, ha="right", va="top")
axes[1].text(1112, 200, " 898/900 inverters", color="red", fontsize=7, ha="left", va="top")
axes[1].text(2378, 60, " 144-T registers, 71 %", color="red", fontsize=7, ha="left", va="top")
fig.tight_layout()
fig.savefig("/home/claude/fig3_yield_ladder.png", dpi=300)
print("ok")
